chrome.tabs.onUpdated.addListener((_tabId, _changeInfo, _tab) => {
});
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  await chrome.sidePanel.open({ tabId: tab.id });
});
