import sr, { setLogLevel as Ye, ExtensionSession as ir, registerJsCallBatch as ar, takeCachedVfsWriteBase64 as or, webFsReadBase64 as dr, clearVfsWriteCache as cr } from "./extension_js.js";
function me(t) {
  return t == null ? {} : t instanceof Map ? Object.fromEntries(
    [...t.entries()].map(([e, r]) => [
      e,
      me(r)
    ])
  ) : Array.isArray(t) ? t.map(me) : t;
}
function lr(t) {
  return {
    action: t.action,
    namespace: t.namespace,
    name: t.name,
    publicName: t.publicName,
    description: t.description,
    fields: t.fields,
    aliases: (t.aliases ?? []).map((e) => ({
      namespace: e.namespace,
      name: e.name,
      fields: e.fields
    })),
    paramsDoc: t.paramsDoc.map((e) => ({
      name: e.name,
      type: e.type,
      required: e.required,
      description: e.description
    })),
    returnsDoc: {
      type: t.returnsDoc.type,
      description: t.returnsDoc.description
    },
    errorCode: t.errorCode,
    errorCategory: t.errorCategory ?? null,
    permission: t.permission ?? null,
    example: t.example ?? null,
    prerequisites: t.prerequisites ?? null,
    notes: t.notes ?? null,
    tags: t.tags ?? null,
    relatedApis: t.relatedApis ?? null
  };
}
var E;
(function(t) {
  t.assertEqual = (s) => {
  };
  function e(s) {
  }
  t.assertIs = e;
  function r(s) {
    throw new Error();
  }
  t.assertNever = r, t.arrayToEnum = (s) => {
    const i = {};
    for (const d of s)
      i[d] = d;
    return i;
  }, t.getValidEnumValues = (s) => {
    const i = t.objectKeys(s).filter((o) => typeof s[s[o]] != "number"), d = {};
    for (const o of i)
      d[o] = s[o];
    return t.objectValues(d);
  }, t.objectValues = (s) => t.objectKeys(s).map(function(i) {
    return s[i];
  }), t.objectKeys = typeof Object.keys == "function" ? (s) => Object.keys(s) : (s) => {
    const i = [];
    for (const d in s)
      Object.prototype.hasOwnProperty.call(s, d) && i.push(d);
    return i;
  }, t.find = (s, i) => {
    for (const d of s)
      if (i(d))
        return d;
  }, t.isInteger = typeof Number.isInteger == "function" ? (s) => Number.isInteger(s) : (s) => typeof s == "number" && Number.isFinite(s) && Math.floor(s) === s;
  function n(s, i = " | ") {
    return s.map((d) => typeof d == "string" ? `'${d}'` : d).join(i);
  }
  t.joinValues = n, t.jsonStringifyReplacer = (s, i) => typeof i == "bigint" ? i.toString() : i;
})(E || (E = {}));
var _t;
(function(t) {
  t.mergeShapes = (e, r) => ({
    ...e,
    ...r
    // second overwrites first
  });
})(_t || (_t = {}));
const g = E.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]), re = (t) => {
  switch (typeof t) {
    case "undefined":
      return g.undefined;
    case "string":
      return g.string;
    case "number":
      return Number.isNaN(t) ? g.nan : g.number;
    case "boolean":
      return g.boolean;
    case "function":
      return g.function;
    case "bigint":
      return g.bigint;
    case "symbol":
      return g.symbol;
    case "object":
      return Array.isArray(t) ? g.array : t === null ? g.null : t.then && typeof t.then == "function" && t.catch && typeof t.catch == "function" ? g.promise : typeof Map < "u" && t instanceof Map ? g.map : typeof Set < "u" && t instanceof Set ? g.set : typeof Date < "u" && t instanceof Date ? g.date : g.object;
    default:
      return g.unknown;
  }
}, u = E.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
class Z extends Error {
  get errors() {
    return this.issues;
  }
  constructor(e) {
    super(), this.issues = [], this.addIssue = (n) => {
      this.issues = [...this.issues, n];
    }, this.addIssues = (n = []) => {
      this.issues = [...this.issues, ...n];
    };
    const r = new.target.prototype;
    Object.setPrototypeOf ? Object.setPrototypeOf(this, r) : this.__proto__ = r, this.name = "ZodError", this.issues = e;
  }
  format(e) {
    const r = e || function(i) {
      return i.message;
    }, n = { _errors: [] }, s = (i) => {
      for (const d of i.issues)
        if (d.code === "invalid_union")
          d.unionErrors.map(s);
        else if (d.code === "invalid_return_type")
          s(d.returnTypeError);
        else if (d.code === "invalid_arguments")
          s(d.argumentsError);
        else if (d.path.length === 0)
          n._errors.push(r(d));
        else {
          let o = n, p = 0;
          for (; p < d.path.length; ) {
            const l = d.path[p];
            p === d.path.length - 1 ? (o[l] = o[l] || { _errors: [] }, o[l]._errors.push(r(d))) : o[l] = o[l] || { _errors: [] }, o = o[l], p++;
          }
        }
    };
    return s(this), n;
  }
  static assert(e) {
    if (!(e instanceof Z))
      throw new Error(`Not a ZodError: ${e}`);
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, E.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(e = (r) => r.message) {
    const r = {}, n = [];
    for (const s of this.issues)
      if (s.path.length > 0) {
        const i = s.path[0];
        r[i] = r[i] || [], r[i].push(e(s));
      } else
        n.push(e(s));
    return { formErrors: n, fieldErrors: r };
  }
  get formErrors() {
    return this.flatten();
  }
}
Z.create = (t) => new Z(t);
const Se = (t, e) => {
  let r;
  switch (t.code) {
    case u.invalid_type:
      t.received === g.undefined ? r = "Required" : r = `Expected ${t.expected}, received ${t.received}`;
      break;
    case u.invalid_literal:
      r = `Invalid literal value, expected ${JSON.stringify(t.expected, E.jsonStringifyReplacer)}`;
      break;
    case u.unrecognized_keys:
      r = `Unrecognized key(s) in object: ${E.joinValues(t.keys, ", ")}`;
      break;
    case u.invalid_union:
      r = "Invalid input";
      break;
    case u.invalid_union_discriminator:
      r = `Invalid discriminator value. Expected ${E.joinValues(t.options)}`;
      break;
    case u.invalid_enum_value:
      r = `Invalid enum value. Expected ${E.joinValues(t.options)}, received '${t.received}'`;
      break;
    case u.invalid_arguments:
      r = "Invalid function arguments";
      break;
    case u.invalid_return_type:
      r = "Invalid function return type";
      break;
    case u.invalid_date:
      r = "Invalid date";
      break;
    case u.invalid_string:
      typeof t.validation == "object" ? "includes" in t.validation ? (r = `Invalid input: must include "${t.validation.includes}"`, typeof t.validation.position == "number" && (r = `${r} at one or more positions greater than or equal to ${t.validation.position}`)) : "startsWith" in t.validation ? r = `Invalid input: must start with "${t.validation.startsWith}"` : "endsWith" in t.validation ? r = `Invalid input: must end with "${t.validation.endsWith}"` : E.assertNever(t.validation) : t.validation !== "regex" ? r = `Invalid ${t.validation}` : r = "Invalid";
      break;
    case u.too_small:
      t.type === "array" ? r = `Array must contain ${t.exact ? "exactly" : t.inclusive ? "at least" : "more than"} ${t.minimum} element(s)` : t.type === "string" ? r = `String must contain ${t.exact ? "exactly" : t.inclusive ? "at least" : "over"} ${t.minimum} character(s)` : t.type === "number" ? r = `Number must be ${t.exact ? "exactly equal to " : t.inclusive ? "greater than or equal to " : "greater than "}${t.minimum}` : t.type === "bigint" ? r = `Number must be ${t.exact ? "exactly equal to " : t.inclusive ? "greater than or equal to " : "greater than "}${t.minimum}` : t.type === "date" ? r = `Date must be ${t.exact ? "exactly equal to " : t.inclusive ? "greater than or equal to " : "greater than "}${new Date(Number(t.minimum))}` : r = "Invalid input";
      break;
    case u.too_big:
      t.type === "array" ? r = `Array must contain ${t.exact ? "exactly" : t.inclusive ? "at most" : "less than"} ${t.maximum} element(s)` : t.type === "string" ? r = `String must contain ${t.exact ? "exactly" : t.inclusive ? "at most" : "under"} ${t.maximum} character(s)` : t.type === "number" ? r = `Number must be ${t.exact ? "exactly" : t.inclusive ? "less than or equal to" : "less than"} ${t.maximum}` : t.type === "bigint" ? r = `BigInt must be ${t.exact ? "exactly" : t.inclusive ? "less than or equal to" : "less than"} ${t.maximum}` : t.type === "date" ? r = `Date must be ${t.exact ? "exactly" : t.inclusive ? "smaller than or equal to" : "smaller than"} ${new Date(Number(t.maximum))}` : r = "Invalid input";
      break;
    case u.custom:
      r = "Invalid input";
      break;
    case u.invalid_intersection_types:
      r = "Intersection results could not be merged";
      break;
    case u.not_multiple_of:
      r = `Number must be a multiple of ${t.multipleOf}`;
      break;
    case u.not_finite:
      r = "Number must be finite";
      break;
    default:
      r = e.defaultError, E.assertNever(t);
  }
  return { message: r };
};
let ur = Se;
function Ke() {
  return ur;
}
const Qe = (t) => {
  const { data: e, path: r, errorMaps: n, issueData: s } = t, i = [...r, ...s.path || []], d = {
    ...s,
    path: i
  };
  if (s.message !== void 0)
    return {
      ...s,
      path: i,
      message: s.message
    };
  let o = "";
  const p = n.filter((l) => !!l).slice().reverse();
  for (const l of p)
    o = l(d, { data: e, defaultError: o }).message;
  return {
    ...s,
    path: i,
    message: o
  };
};
function h(t, e) {
  const r = Ke(), n = Qe({
    issueData: e,
    data: t.data,
    path: t.path,
    errorMaps: [
      t.common.contextualErrorMap,
      // contextual error map is first priority
      t.schemaErrorMap,
      // then schema-bound map if available
      r,
      // then global override map
      r === Se ? void 0 : Se
      // then global default map
    ].filter((s) => !!s)
  });
  t.common.issues.push(n);
}
class L {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    this.value === "valid" && (this.value = "dirty");
  }
  abort() {
    this.value !== "aborted" && (this.value = "aborted");
  }
  static mergeArray(e, r) {
    const n = [];
    for (const s of r) {
      if (s.status === "aborted")
        return k;
      s.status === "dirty" && e.dirty(), n.push(s.value);
    }
    return { status: e.value, value: n };
  }
  static async mergeObjectAsync(e, r) {
    const n = [];
    for (const s of r) {
      const i = await s.key, d = await s.value;
      n.push({
        key: i,
        value: d
      });
    }
    return L.mergeObjectSync(e, n);
  }
  static mergeObjectSync(e, r) {
    const n = {};
    for (const s of r) {
      const { key: i, value: d } = s;
      if (i.status === "aborted" || d.status === "aborted")
        return k;
      i.status === "dirty" && e.dirty(), d.status === "dirty" && e.dirty(), i.value !== "__proto__" && (typeof d.value < "u" || s.alwaysSet) && (n[i.value] = d.value);
    }
    return { status: e.value, value: n };
  }
}
const k = Object.freeze({
  status: "aborted"
}), ke = (t) => ({ status: "dirty", value: t }), P = (t) => ({ status: "valid", value: t }), vt = (t) => t.status === "aborted", kt = (t) => t.status === "dirty", ge = (t) => t.status === "valid", je = (t) => typeof Promise < "u" && t instanceof Promise;
var y;
(function(t) {
  t.errToObj = (e) => typeof e == "string" ? { message: e } : e || {}, t.toString = (e) => typeof e == "string" ? e : e == null ? void 0 : e.message;
})(y || (y = {}));
class H {
  constructor(e, r, n, s) {
    this._cachedPath = [], this.parent = e, this.data = r, this._path = n, this._key = s;
  }
  get path() {
    return this._cachedPath.length || (Array.isArray(this._key) ? this._cachedPath.push(...this._path, ...this._key) : this._cachedPath.push(...this._path, this._key)), this._cachedPath;
  }
}
const wt = (t, e) => {
  if (ge(e))
    return { success: !0, data: e.value };
  if (!t.common.issues.length)
    throw new Error("Validation failed but no issues detected.");
  return {
    success: !1,
    get error() {
      if (this._error)
        return this._error;
      const r = new Z(t.common.issues);
      return this._error = r, this._error;
    }
  };
};
function x(t) {
  if (!t)
    return {};
  const { errorMap: e, invalid_type_error: r, required_error: n, description: s } = t;
  if (e && (r || n))
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  return e ? { errorMap: e, description: s } : { errorMap: (d, o) => {
    const { message: p } = t;
    return d.code === "invalid_enum_value" ? { message: p ?? o.defaultError } : typeof o.data > "u" ? { message: p ?? n ?? o.defaultError } : d.code !== "invalid_type" ? { message: o.defaultError } : { message: p ?? r ?? o.defaultError };
  }, description: s };
}
class S {
  get description() {
    return this._def.description;
  }
  _getType(e) {
    return re(e.data);
  }
  _getOrReturnCtx(e, r) {
    return r || {
      common: e.parent.common,
      data: e.data,
      parsedType: re(e.data),
      schemaErrorMap: this._def.errorMap,
      path: e.path,
      parent: e.parent
    };
  }
  _processInputParams(e) {
    return {
      status: new L(),
      ctx: {
        common: e.parent.common,
        data: e.data,
        parsedType: re(e.data),
        schemaErrorMap: this._def.errorMap,
        path: e.path,
        parent: e.parent
      }
    };
  }
  _parseSync(e) {
    const r = this._parse(e);
    if (je(r))
      throw new Error("Synchronous parse encountered promise.");
    return r;
  }
  _parseAsync(e) {
    const r = this._parse(e);
    return Promise.resolve(r);
  }
  parse(e, r) {
    const n = this.safeParse(e, r);
    if (n.success)
      return n.data;
    throw n.error;
  }
  safeParse(e, r) {
    const n = {
      common: {
        issues: [],
        async: (r == null ? void 0 : r.async) ?? !1,
        contextualErrorMap: r == null ? void 0 : r.errorMap
      },
      path: (r == null ? void 0 : r.path) || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data: e,
      parsedType: re(e)
    }, s = this._parseSync({ data: e, path: n.path, parent: n });
    return wt(n, s);
  }
  "~validate"(e) {
    var n, s;
    const r = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data: e,
      parsedType: re(e)
    };
    if (!this["~standard"].async)
      try {
        const i = this._parseSync({ data: e, path: [], parent: r });
        return ge(i) ? {
          value: i.value
        } : {
          issues: r.common.issues
        };
      } catch (i) {
        (s = (n = i == null ? void 0 : i.message) == null ? void 0 : n.toLowerCase()) != null && s.includes("encountered") && (this["~standard"].async = !0), r.common = {
          issues: [],
          async: !0
        };
      }
    return this._parseAsync({ data: e, path: [], parent: r }).then((i) => ge(i) ? {
      value: i.value
    } : {
      issues: r.common.issues
    });
  }
  async parseAsync(e, r) {
    const n = await this.safeParseAsync(e, r);
    if (n.success)
      return n.data;
    throw n.error;
  }
  async safeParseAsync(e, r) {
    const n = {
      common: {
        issues: [],
        contextualErrorMap: r == null ? void 0 : r.errorMap,
        async: !0
      },
      path: (r == null ? void 0 : r.path) || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data: e,
      parsedType: re(e)
    }, s = this._parse({ data: e, path: n.path, parent: n }), i = await (je(s) ? s : Promise.resolve(s));
    return wt(n, i);
  }
  refine(e, r) {
    const n = (s) => typeof r == "string" || typeof r > "u" ? { message: r } : typeof r == "function" ? r(s) : r;
    return this._refinement((s, i) => {
      const d = e(s), o = () => i.addIssue({
        code: u.custom,
        ...n(s)
      });
      return typeof Promise < "u" && d instanceof Promise ? d.then((p) => p ? !0 : (o(), !1)) : d ? !0 : (o(), !1);
    });
  }
  refinement(e, r) {
    return this._refinement((n, s) => e(n) ? !0 : (s.addIssue(typeof r == "function" ? r(n, s) : r), !1));
  }
  _refinement(e) {
    return new X({
      schema: this,
      typeName: w.ZodEffects,
      effect: { type: "refinement", refinement: e }
    });
  }
  superRefine(e) {
    return this._refinement(e);
  }
  constructor(e) {
    this.spa = this.safeParseAsync, this._def = e, this.parse = this.parse.bind(this), this.safeParse = this.safeParse.bind(this), this.parseAsync = this.parseAsync.bind(this), this.safeParseAsync = this.safeParseAsync.bind(this), this.spa = this.spa.bind(this), this.refine = this.refine.bind(this), this.refinement = this.refinement.bind(this), this.superRefine = this.superRefine.bind(this), this.optional = this.optional.bind(this), this.nullable = this.nullable.bind(this), this.nullish = this.nullish.bind(this), this.array = this.array.bind(this), this.promise = this.promise.bind(this), this.or = this.or.bind(this), this.and = this.and.bind(this), this.transform = this.transform.bind(this), this.brand = this.brand.bind(this), this.default = this.default.bind(this), this.catch = this.catch.bind(this), this.describe = this.describe.bind(this), this.pipe = this.pipe.bind(this), this.readonly = this.readonly.bind(this), this.isNullable = this.isNullable.bind(this), this.isOptional = this.isOptional.bind(this), this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (r) => this["~validate"](r)
    };
  }
  optional() {
    return U.create(this, this._def);
  }
  nullable() {
    return ie.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return F.create(this);
  }
  promise() {
    return be.create(this, this._def);
  }
  or(e) {
    return Re.create([this, e], this._def);
  }
  and(e) {
    return Ce.create(this, e, this._def);
  }
  transform(e) {
    return new X({
      ...x(this._def),
      schema: this,
      typeName: w.ZodEffects,
      effect: { type: "transform", transform: e }
    });
  }
  default(e) {
    const r = typeof e == "function" ? e : () => e;
    return new Ne({
      ...x(this._def),
      innerType: this,
      defaultValue: r,
      typeName: w.ZodDefault
    });
  }
  brand() {
    return new ct({
      typeName: w.ZodBranded,
      type: this,
      ...x(this._def)
    });
  }
  catch(e) {
    const r = typeof e == "function" ? e : () => e;
    return new $e({
      ...x(this._def),
      innerType: this,
      catchValue: r,
      typeName: w.ZodCatch
    });
  }
  describe(e) {
    const r = this.constructor;
    return new r({
      ...this._def,
      description: e
    });
  }
  pipe(e) {
    return qe.create(this, e);
  }
  readonly() {
    return Le.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
}
const fr = /^c[^\s-]{8,}$/i, pr = /^[0-9a-z]+$/, hr = /^[0-9A-HJKMNP-TV-Z]{26}$/i, mr = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i, gr = /^[a-z0-9_-]{21}$/i, yr = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/, br = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, _r = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i, vr = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
let Ge;
const kr = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, wr = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/, xr = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/, Tr = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Sr = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/, Ir = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/, Mt = "((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))", Er = new RegExp(`^${Mt}$`);
function Nt(t) {
  let e = "[0-5]\\d";
  t.precision ? e = `${e}\\.\\d{${t.precision}}` : t.precision == null && (e = `${e}(\\.\\d+)?`);
  const r = t.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${e})${r}`;
}
function Rr(t) {
  return new RegExp(`^${Nt(t)}$`);
}
function Cr(t) {
  let e = `${Mt}T${Nt(t)}`;
  const r = [];
  return r.push(t.local ? "Z?" : "Z"), t.offset && r.push("([+-]\\d{2}:?\\d{2})"), e = `${e}(${r.join("|")})`, new RegExp(`^${e}$`);
}
function Ar(t, e) {
  return !!((e === "v4" || !e) && kr.test(t) || (e === "v6" || !e) && xr.test(t));
}
function Or(t, e) {
  if (!yr.test(t))
    return !1;
  try {
    const [r] = t.split(".");
    if (!r)
      return !1;
    const n = r.replace(/-/g, "+").replace(/_/g, "/").padEnd(r.length + (4 - r.length % 4) % 4, "="), s = JSON.parse(atob(n));
    return !(typeof s != "object" || s === null || "typ" in s && (s == null ? void 0 : s.typ) !== "JWT" || !s.alg || e && s.alg !== e);
  } catch {
    return !1;
  }
}
function Mr(t, e) {
  return !!((e === "v4" || !e) && wr.test(t) || (e === "v6" || !e) && Tr.test(t));
}
class q extends S {
  _parse(e) {
    if (this._def.coerce && (e.data = String(e.data)), this._getType(e) !== g.string) {
      const i = this._getOrReturnCtx(e);
      return h(i, {
        code: u.invalid_type,
        expected: g.string,
        received: i.parsedType
      }), k;
    }
    const n = new L();
    let s;
    for (const i of this._def.checks)
      if (i.kind === "min")
        e.data.length < i.value && (s = this._getOrReturnCtx(e, s), h(s, {
          code: u.too_small,
          minimum: i.value,
          type: "string",
          inclusive: !0,
          exact: !1,
          message: i.message
        }), n.dirty());
      else if (i.kind === "max")
        e.data.length > i.value && (s = this._getOrReturnCtx(e, s), h(s, {
          code: u.too_big,
          maximum: i.value,
          type: "string",
          inclusive: !0,
          exact: !1,
          message: i.message
        }), n.dirty());
      else if (i.kind === "length") {
        const d = e.data.length > i.value, o = e.data.length < i.value;
        (d || o) && (s = this._getOrReturnCtx(e, s), d ? h(s, {
          code: u.too_big,
          maximum: i.value,
          type: "string",
          inclusive: !0,
          exact: !0,
          message: i.message
        }) : o && h(s, {
          code: u.too_small,
          minimum: i.value,
          type: "string",
          inclusive: !0,
          exact: !0,
          message: i.message
        }), n.dirty());
      } else if (i.kind === "email")
        _r.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
          validation: "email",
          code: u.invalid_string,
          message: i.message
        }), n.dirty());
      else if (i.kind === "emoji")
        Ge || (Ge = new RegExp(vr, "u")), Ge.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
          validation: "emoji",
          code: u.invalid_string,
          message: i.message
        }), n.dirty());
      else if (i.kind === "uuid")
        mr.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
          validation: "uuid",
          code: u.invalid_string,
          message: i.message
        }), n.dirty());
      else if (i.kind === "nanoid")
        gr.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
          validation: "nanoid",
          code: u.invalid_string,
          message: i.message
        }), n.dirty());
      else if (i.kind === "cuid")
        fr.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
          validation: "cuid",
          code: u.invalid_string,
          message: i.message
        }), n.dirty());
      else if (i.kind === "cuid2")
        pr.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
          validation: "cuid2",
          code: u.invalid_string,
          message: i.message
        }), n.dirty());
      else if (i.kind === "ulid")
        hr.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
          validation: "ulid",
          code: u.invalid_string,
          message: i.message
        }), n.dirty());
      else if (i.kind === "url")
        try {
          new URL(e.data);
        } catch {
          s = this._getOrReturnCtx(e, s), h(s, {
            validation: "url",
            code: u.invalid_string,
            message: i.message
          }), n.dirty();
        }
      else i.kind === "regex" ? (i.regex.lastIndex = 0, i.regex.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
        validation: "regex",
        code: u.invalid_string,
        message: i.message
      }), n.dirty())) : i.kind === "trim" ? e.data = e.data.trim() : i.kind === "includes" ? e.data.includes(i.value, i.position) || (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.invalid_string,
        validation: { includes: i.value, position: i.position },
        message: i.message
      }), n.dirty()) : i.kind === "toLowerCase" ? e.data = e.data.toLowerCase() : i.kind === "toUpperCase" ? e.data = e.data.toUpperCase() : i.kind === "startsWith" ? e.data.startsWith(i.value) || (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.invalid_string,
        validation: { startsWith: i.value },
        message: i.message
      }), n.dirty()) : i.kind === "endsWith" ? e.data.endsWith(i.value) || (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.invalid_string,
        validation: { endsWith: i.value },
        message: i.message
      }), n.dirty()) : i.kind === "datetime" ? Cr(i).test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.invalid_string,
        validation: "datetime",
        message: i.message
      }), n.dirty()) : i.kind === "date" ? Er.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.invalid_string,
        validation: "date",
        message: i.message
      }), n.dirty()) : i.kind === "time" ? Rr(i).test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.invalid_string,
        validation: "time",
        message: i.message
      }), n.dirty()) : i.kind === "duration" ? br.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
        validation: "duration",
        code: u.invalid_string,
        message: i.message
      }), n.dirty()) : i.kind === "ip" ? Ar(e.data, i.version) || (s = this._getOrReturnCtx(e, s), h(s, {
        validation: "ip",
        code: u.invalid_string,
        message: i.message
      }), n.dirty()) : i.kind === "jwt" ? Or(e.data, i.alg) || (s = this._getOrReturnCtx(e, s), h(s, {
        validation: "jwt",
        code: u.invalid_string,
        message: i.message
      }), n.dirty()) : i.kind === "cidr" ? Mr(e.data, i.version) || (s = this._getOrReturnCtx(e, s), h(s, {
        validation: "cidr",
        code: u.invalid_string,
        message: i.message
      }), n.dirty()) : i.kind === "base64" ? Sr.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
        validation: "base64",
        code: u.invalid_string,
        message: i.message
      }), n.dirty()) : i.kind === "base64url" ? Ir.test(e.data) || (s = this._getOrReturnCtx(e, s), h(s, {
        validation: "base64url",
        code: u.invalid_string,
        message: i.message
      }), n.dirty()) : E.assertNever(i);
    return { status: n.value, value: e.data };
  }
  _regex(e, r, n) {
    return this.refinement((s) => e.test(s), {
      validation: r,
      code: u.invalid_string,
      ...y.errToObj(n)
    });
  }
  _addCheck(e) {
    return new q({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  email(e) {
    return this._addCheck({ kind: "email", ...y.errToObj(e) });
  }
  url(e) {
    return this._addCheck({ kind: "url", ...y.errToObj(e) });
  }
  emoji(e) {
    return this._addCheck({ kind: "emoji", ...y.errToObj(e) });
  }
  uuid(e) {
    return this._addCheck({ kind: "uuid", ...y.errToObj(e) });
  }
  nanoid(e) {
    return this._addCheck({ kind: "nanoid", ...y.errToObj(e) });
  }
  cuid(e) {
    return this._addCheck({ kind: "cuid", ...y.errToObj(e) });
  }
  cuid2(e) {
    return this._addCheck({ kind: "cuid2", ...y.errToObj(e) });
  }
  ulid(e) {
    return this._addCheck({ kind: "ulid", ...y.errToObj(e) });
  }
  base64(e) {
    return this._addCheck({ kind: "base64", ...y.errToObj(e) });
  }
  base64url(e) {
    return this._addCheck({
      kind: "base64url",
      ...y.errToObj(e)
    });
  }
  jwt(e) {
    return this._addCheck({ kind: "jwt", ...y.errToObj(e) });
  }
  ip(e) {
    return this._addCheck({ kind: "ip", ...y.errToObj(e) });
  }
  cidr(e) {
    return this._addCheck({ kind: "cidr", ...y.errToObj(e) });
  }
  datetime(e) {
    return typeof e == "string" ? this._addCheck({
      kind: "datetime",
      precision: null,
      offset: !1,
      local: !1,
      message: e
    }) : this._addCheck({
      kind: "datetime",
      precision: typeof (e == null ? void 0 : e.precision) > "u" ? null : e == null ? void 0 : e.precision,
      offset: (e == null ? void 0 : e.offset) ?? !1,
      local: (e == null ? void 0 : e.local) ?? !1,
      ...y.errToObj(e == null ? void 0 : e.message)
    });
  }
  date(e) {
    return this._addCheck({ kind: "date", message: e });
  }
  time(e) {
    return typeof e == "string" ? this._addCheck({
      kind: "time",
      precision: null,
      message: e
    }) : this._addCheck({
      kind: "time",
      precision: typeof (e == null ? void 0 : e.precision) > "u" ? null : e == null ? void 0 : e.precision,
      ...y.errToObj(e == null ? void 0 : e.message)
    });
  }
  duration(e) {
    return this._addCheck({ kind: "duration", ...y.errToObj(e) });
  }
  regex(e, r) {
    return this._addCheck({
      kind: "regex",
      regex: e,
      ...y.errToObj(r)
    });
  }
  includes(e, r) {
    return this._addCheck({
      kind: "includes",
      value: e,
      position: r == null ? void 0 : r.position,
      ...y.errToObj(r == null ? void 0 : r.message)
    });
  }
  startsWith(e, r) {
    return this._addCheck({
      kind: "startsWith",
      value: e,
      ...y.errToObj(r)
    });
  }
  endsWith(e, r) {
    return this._addCheck({
      kind: "endsWith",
      value: e,
      ...y.errToObj(r)
    });
  }
  min(e, r) {
    return this._addCheck({
      kind: "min",
      value: e,
      ...y.errToObj(r)
    });
  }
  max(e, r) {
    return this._addCheck({
      kind: "max",
      value: e,
      ...y.errToObj(r)
    });
  }
  length(e, r) {
    return this._addCheck({
      kind: "length",
      value: e,
      ...y.errToObj(r)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(e) {
    return this.min(1, y.errToObj(e));
  }
  trim() {
    return new q({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new q({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new q({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((e) => e.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((e) => e.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((e) => e.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((e) => e.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((e) => e.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((e) => e.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((e) => e.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((e) => e.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((e) => e.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((e) => e.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((e) => e.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((e) => e.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((e) => e.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((e) => e.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((e) => e.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((e) => e.kind === "base64url");
  }
  get minLength() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "min" && (e === null || r.value > e) && (e = r.value);
    return e;
  }
  get maxLength() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "max" && (e === null || r.value < e) && (e = r.value);
    return e;
  }
}
q.create = (t) => new q({
  checks: [],
  typeName: w.ZodString,
  coerce: (t == null ? void 0 : t.coerce) ?? !1,
  ...x(t)
});
function Nr(t, e) {
  const r = (t.toString().split(".")[1] || "").length, n = (e.toString().split(".")[1] || "").length, s = r > n ? r : n, i = Number.parseInt(t.toFixed(s).replace(".", "")), d = Number.parseInt(e.toFixed(s).replace(".", ""));
  return i % d / 10 ** s;
}
class oe extends S {
  constructor() {
    super(...arguments), this.min = this.gte, this.max = this.lte, this.step = this.multipleOf;
  }
  _parse(e) {
    if (this._def.coerce && (e.data = Number(e.data)), this._getType(e) !== g.number) {
      const i = this._getOrReturnCtx(e);
      return h(i, {
        code: u.invalid_type,
        expected: g.number,
        received: i.parsedType
      }), k;
    }
    let n;
    const s = new L();
    for (const i of this._def.checks)
      i.kind === "int" ? E.isInteger(e.data) || (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.invalid_type,
        expected: "integer",
        received: "float",
        message: i.message
      }), s.dirty()) : i.kind === "min" ? (i.inclusive ? e.data < i.value : e.data <= i.value) && (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.too_small,
        minimum: i.value,
        type: "number",
        inclusive: i.inclusive,
        exact: !1,
        message: i.message
      }), s.dirty()) : i.kind === "max" ? (i.inclusive ? e.data > i.value : e.data >= i.value) && (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.too_big,
        maximum: i.value,
        type: "number",
        inclusive: i.inclusive,
        exact: !1,
        message: i.message
      }), s.dirty()) : i.kind === "multipleOf" ? Nr(e.data, i.value) !== 0 && (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.not_multiple_of,
        multipleOf: i.value,
        message: i.message
      }), s.dirty()) : i.kind === "finite" ? Number.isFinite(e.data) || (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.not_finite,
        message: i.message
      }), s.dirty()) : E.assertNever(i);
    return { status: s.value, value: e.data };
  }
  gte(e, r) {
    return this.setLimit("min", e, !0, y.toString(r));
  }
  gt(e, r) {
    return this.setLimit("min", e, !1, y.toString(r));
  }
  lte(e, r) {
    return this.setLimit("max", e, !0, y.toString(r));
  }
  lt(e, r) {
    return this.setLimit("max", e, !1, y.toString(r));
  }
  setLimit(e, r, n, s) {
    return new oe({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind: e,
          value: r,
          inclusive: n,
          message: y.toString(s)
        }
      ]
    });
  }
  _addCheck(e) {
    return new oe({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  int(e) {
    return this._addCheck({
      kind: "int",
      message: y.toString(e)
    });
  }
  positive(e) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: !1,
      message: y.toString(e)
    });
  }
  negative(e) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: !1,
      message: y.toString(e)
    });
  }
  nonpositive(e) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: !0,
      message: y.toString(e)
    });
  }
  nonnegative(e) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: !0,
      message: y.toString(e)
    });
  }
  multipleOf(e, r) {
    return this._addCheck({
      kind: "multipleOf",
      value: e,
      message: y.toString(r)
    });
  }
  finite(e) {
    return this._addCheck({
      kind: "finite",
      message: y.toString(e)
    });
  }
  safe(e) {
    return this._addCheck({
      kind: "min",
      inclusive: !0,
      value: Number.MIN_SAFE_INTEGER,
      message: y.toString(e)
    })._addCheck({
      kind: "max",
      inclusive: !0,
      value: Number.MAX_SAFE_INTEGER,
      message: y.toString(e)
    });
  }
  get minValue() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "min" && (e === null || r.value > e) && (e = r.value);
    return e;
  }
  get maxValue() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "max" && (e === null || r.value < e) && (e = r.value);
    return e;
  }
  get isInt() {
    return !!this._def.checks.find((e) => e.kind === "int" || e.kind === "multipleOf" && E.isInteger(e.value));
  }
  get isFinite() {
    let e = null, r = null;
    for (const n of this._def.checks) {
      if (n.kind === "finite" || n.kind === "int" || n.kind === "multipleOf")
        return !0;
      n.kind === "min" ? (r === null || n.value > r) && (r = n.value) : n.kind === "max" && (e === null || n.value < e) && (e = n.value);
    }
    return Number.isFinite(r) && Number.isFinite(e);
  }
}
oe.create = (t) => new oe({
  checks: [],
  typeName: w.ZodNumber,
  coerce: (t == null ? void 0 : t.coerce) || !1,
  ...x(t)
});
class de extends S {
  constructor() {
    super(...arguments), this.min = this.gte, this.max = this.lte;
  }
  _parse(e) {
    if (this._def.coerce)
      try {
        e.data = BigInt(e.data);
      } catch {
        return this._getInvalidInput(e);
      }
    if (this._getType(e) !== g.bigint)
      return this._getInvalidInput(e);
    let n;
    const s = new L();
    for (const i of this._def.checks)
      i.kind === "min" ? (i.inclusive ? e.data < i.value : e.data <= i.value) && (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.too_small,
        type: "bigint",
        minimum: i.value,
        inclusive: i.inclusive,
        message: i.message
      }), s.dirty()) : i.kind === "max" ? (i.inclusive ? e.data > i.value : e.data >= i.value) && (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.too_big,
        type: "bigint",
        maximum: i.value,
        inclusive: i.inclusive,
        message: i.message
      }), s.dirty()) : i.kind === "multipleOf" ? e.data % i.value !== BigInt(0) && (n = this._getOrReturnCtx(e, n), h(n, {
        code: u.not_multiple_of,
        multipleOf: i.value,
        message: i.message
      }), s.dirty()) : E.assertNever(i);
    return { status: s.value, value: e.data };
  }
  _getInvalidInput(e) {
    const r = this._getOrReturnCtx(e);
    return h(r, {
      code: u.invalid_type,
      expected: g.bigint,
      received: r.parsedType
    }), k;
  }
  gte(e, r) {
    return this.setLimit("min", e, !0, y.toString(r));
  }
  gt(e, r) {
    return this.setLimit("min", e, !1, y.toString(r));
  }
  lte(e, r) {
    return this.setLimit("max", e, !0, y.toString(r));
  }
  lt(e, r) {
    return this.setLimit("max", e, !1, y.toString(r));
  }
  setLimit(e, r, n, s) {
    return new de({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind: e,
          value: r,
          inclusive: n,
          message: y.toString(s)
        }
      ]
    });
  }
  _addCheck(e) {
    return new de({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  positive(e) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: !1,
      message: y.toString(e)
    });
  }
  negative(e) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: !1,
      message: y.toString(e)
    });
  }
  nonpositive(e) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: !0,
      message: y.toString(e)
    });
  }
  nonnegative(e) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: !0,
      message: y.toString(e)
    });
  }
  multipleOf(e, r) {
    return this._addCheck({
      kind: "multipleOf",
      value: e,
      message: y.toString(r)
    });
  }
  get minValue() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "min" && (e === null || r.value > e) && (e = r.value);
    return e;
  }
  get maxValue() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "max" && (e === null || r.value < e) && (e = r.value);
    return e;
  }
}
de.create = (t) => new de({
  checks: [],
  typeName: w.ZodBigInt,
  coerce: (t == null ? void 0 : t.coerce) ?? !1,
  ...x(t)
});
class De extends S {
  _parse(e) {
    if (this._def.coerce && (e.data = !!e.data), this._getType(e) !== g.boolean) {
      const n = this._getOrReturnCtx(e);
      return h(n, {
        code: u.invalid_type,
        expected: g.boolean,
        received: n.parsedType
      }), k;
    }
    return P(e.data);
  }
}
De.create = (t) => new De({
  typeName: w.ZodBoolean,
  coerce: (t == null ? void 0 : t.coerce) || !1,
  ...x(t)
});
class Ie extends S {
  _parse(e) {
    if (this._def.coerce && (e.data = new Date(e.data)), this._getType(e) !== g.date) {
      const i = this._getOrReturnCtx(e);
      return h(i, {
        code: u.invalid_type,
        expected: g.date,
        received: i.parsedType
      }), k;
    }
    if (Number.isNaN(e.data.getTime())) {
      const i = this._getOrReturnCtx(e);
      return h(i, {
        code: u.invalid_date
      }), k;
    }
    const n = new L();
    let s;
    for (const i of this._def.checks)
      i.kind === "min" ? e.data.getTime() < i.value && (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.too_small,
        message: i.message,
        inclusive: !0,
        exact: !1,
        minimum: i.value,
        type: "date"
      }), n.dirty()) : i.kind === "max" ? e.data.getTime() > i.value && (s = this._getOrReturnCtx(e, s), h(s, {
        code: u.too_big,
        message: i.message,
        inclusive: !0,
        exact: !1,
        maximum: i.value,
        type: "date"
      }), n.dirty()) : E.assertNever(i);
    return {
      status: n.value,
      value: new Date(e.data.getTime())
    };
  }
  _addCheck(e) {
    return new Ie({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  min(e, r) {
    return this._addCheck({
      kind: "min",
      value: e.getTime(),
      message: y.toString(r)
    });
  }
  max(e, r) {
    return this._addCheck({
      kind: "max",
      value: e.getTime(),
      message: y.toString(r)
    });
  }
  get minDate() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "min" && (e === null || r.value > e) && (e = r.value);
    return e != null ? new Date(e) : null;
  }
  get maxDate() {
    let e = null;
    for (const r of this._def.checks)
      r.kind === "max" && (e === null || r.value < e) && (e = r.value);
    return e != null ? new Date(e) : null;
  }
}
Ie.create = (t) => new Ie({
  checks: [],
  coerce: (t == null ? void 0 : t.coerce) || !1,
  typeName: w.ZodDate,
  ...x(t)
});
class xt extends S {
  _parse(e) {
    if (this._getType(e) !== g.symbol) {
      const n = this._getOrReturnCtx(e);
      return h(n, {
        code: u.invalid_type,
        expected: g.symbol,
        received: n.parsedType
      }), k;
    }
    return P(e.data);
  }
}
xt.create = (t) => new xt({
  typeName: w.ZodSymbol,
  ...x(t)
});
class Ze extends S {
  _parse(e) {
    if (this._getType(e) !== g.undefined) {
      const n = this._getOrReturnCtx(e);
      return h(n, {
        code: u.invalid_type,
        expected: g.undefined,
        received: n.parsedType
      }), k;
    }
    return P(e.data);
  }
}
Ze.create = (t) => new Ze({
  typeName: w.ZodUndefined,
  ...x(t)
});
class Ee extends S {
  _parse(e) {
    if (this._getType(e) !== g.null) {
      const n = this._getOrReturnCtx(e);
      return h(n, {
        code: u.invalid_type,
        expected: g.null,
        received: n.parsedType
      }), k;
    }
    return P(e.data);
  }
}
Ee.create = (t) => new Ee({
  typeName: w.ZodNull,
  ...x(t)
});
class Xe extends S {
  constructor() {
    super(...arguments), this._any = !0;
  }
  _parse(e) {
    return P(e.data);
  }
}
Xe.create = (t) => new Xe({
  typeName: w.ZodAny,
  ...x(t)
});
class ae extends S {
  constructor() {
    super(...arguments), this._unknown = !0;
  }
  _parse(e) {
    return P(e.data);
  }
}
ae.create = (t) => new ae({
  typeName: w.ZodUnknown,
  ...x(t)
});
class ne extends S {
  _parse(e) {
    const r = this._getOrReturnCtx(e);
    return h(r, {
      code: u.invalid_type,
      expected: g.never,
      received: r.parsedType
    }), k;
  }
}
ne.create = (t) => new ne({
  typeName: w.ZodNever,
  ...x(t)
});
class et extends S {
  _parse(e) {
    if (this._getType(e) !== g.undefined) {
      const n = this._getOrReturnCtx(e);
      return h(n, {
        code: u.invalid_type,
        expected: g.void,
        received: n.parsedType
      }), k;
    }
    return P(e.data);
  }
}
et.create = (t) => new et({
  typeName: w.ZodVoid,
  ...x(t)
});
class F extends S {
  _parse(e) {
    const { ctx: r, status: n } = this._processInputParams(e), s = this._def;
    if (r.parsedType !== g.array)
      return h(r, {
        code: u.invalid_type,
        expected: g.array,
        received: r.parsedType
      }), k;
    if (s.exactLength !== null) {
      const d = r.data.length > s.exactLength.value, o = r.data.length < s.exactLength.value;
      (d || o) && (h(r, {
        code: d ? u.too_big : u.too_small,
        minimum: o ? s.exactLength.value : void 0,
        maximum: d ? s.exactLength.value : void 0,
        type: "array",
        inclusive: !0,
        exact: !0,
        message: s.exactLength.message
      }), n.dirty());
    }
    if (s.minLength !== null && r.data.length < s.minLength.value && (h(r, {
      code: u.too_small,
      minimum: s.minLength.value,
      type: "array",
      inclusive: !0,
      exact: !1,
      message: s.minLength.message
    }), n.dirty()), s.maxLength !== null && r.data.length > s.maxLength.value && (h(r, {
      code: u.too_big,
      maximum: s.maxLength.value,
      type: "array",
      inclusive: !0,
      exact: !1,
      message: s.maxLength.message
    }), n.dirty()), r.common.async)
      return Promise.all([...r.data].map((d, o) => s.type._parseAsync(new H(r, d, r.path, o)))).then((d) => L.mergeArray(n, d));
    const i = [...r.data].map((d, o) => s.type._parseSync(new H(r, d, r.path, o)));
    return L.mergeArray(n, i);
  }
  get element() {
    return this._def.type;
  }
  min(e, r) {
    return new F({
      ...this._def,
      minLength: { value: e, message: y.toString(r) }
    });
  }
  max(e, r) {
    return new F({
      ...this._def,
      maxLength: { value: e, message: y.toString(r) }
    });
  }
  length(e, r) {
    return new F({
      ...this._def,
      exactLength: { value: e, message: y.toString(r) }
    });
  }
  nonempty(e) {
    return this.min(1, e);
  }
}
F.create = (t, e) => new F({
  type: t,
  minLength: null,
  maxLength: null,
  exactLength: null,
  typeName: w.ZodArray,
  ...x(e)
});
function pe(t) {
  if (t instanceof A) {
    const e = {};
    for (const r in t.shape) {
      const n = t.shape[r];
      e[r] = U.create(pe(n));
    }
    return new A({
      ...t._def,
      shape: () => e
    });
  } else return t instanceof F ? new F({
    ...t._def,
    type: pe(t.element)
  }) : t instanceof U ? U.create(pe(t.unwrap())) : t instanceof ie ? ie.create(pe(t.unwrap())) : t instanceof G ? G.create(t.items.map((e) => pe(e))) : t;
}
class A extends S {
  constructor() {
    super(...arguments), this._cached = null, this.nonstrict = this.passthrough, this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const e = this._def.shape(), r = E.objectKeys(e);
    return this._cached = { shape: e, keys: r }, this._cached;
  }
  _parse(e) {
    if (this._getType(e) !== g.object) {
      const l = this._getOrReturnCtx(e);
      return h(l, {
        code: u.invalid_type,
        expected: g.object,
        received: l.parsedType
      }), k;
    }
    const { status: n, ctx: s } = this._processInputParams(e), { shape: i, keys: d } = this._getCached(), o = [];
    if (!(this._def.catchall instanceof ne && this._def.unknownKeys === "strip"))
      for (const l in s.data)
        d.includes(l) || o.push(l);
    const p = [];
    for (const l of d) {
      const m = i[l], R = s.data[l];
      p.push({
        key: { status: "valid", value: l },
        value: m._parse(new H(s, R, s.path, l)),
        alwaysSet: l in s.data
      });
    }
    if (this._def.catchall instanceof ne) {
      const l = this._def.unknownKeys;
      if (l === "passthrough")
        for (const m of o)
          p.push({
            key: { status: "valid", value: m },
            value: { status: "valid", value: s.data[m] }
          });
      else if (l === "strict")
        o.length > 0 && (h(s, {
          code: u.unrecognized_keys,
          keys: o
        }), n.dirty());
      else if (l !== "strip") throw new Error("Internal ZodObject error: invalid unknownKeys value.");
    } else {
      const l = this._def.catchall;
      for (const m of o) {
        const R = s.data[m];
        p.push({
          key: { status: "valid", value: m },
          value: l._parse(
            new H(s, R, s.path, m)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: m in s.data
        });
      }
    }
    return s.common.async ? Promise.resolve().then(async () => {
      const l = [];
      for (const m of p) {
        const R = await m.key, $ = await m.value;
        l.push({
          key: R,
          value: $,
          alwaysSet: m.alwaysSet
        });
      }
      return l;
    }).then((l) => L.mergeObjectSync(n, l)) : L.mergeObjectSync(n, p);
  }
  get shape() {
    return this._def.shape();
  }
  strict(e) {
    return y.errToObj, new A({
      ...this._def,
      unknownKeys: "strict",
      ...e !== void 0 ? {
        errorMap: (r, n) => {
          var i, d;
          const s = ((d = (i = this._def).errorMap) == null ? void 0 : d.call(i, r, n).message) ?? n.defaultError;
          return r.code === "unrecognized_keys" ? {
            message: y.errToObj(e).message ?? s
          } : {
            message: s
          };
        }
      } : {}
    });
  }
  strip() {
    return new A({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new A({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(e) {
    return new A({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...e
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(e) {
    return new A({
      unknownKeys: e._def.unknownKeys,
      catchall: e._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...e._def.shape()
      }),
      typeName: w.ZodObject
    });
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(e, r) {
    return this.augment({ [e]: r });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(e) {
    return new A({
      ...this._def,
      catchall: e
    });
  }
  pick(e) {
    const r = {};
    for (const n of E.objectKeys(e))
      e[n] && this.shape[n] && (r[n] = this.shape[n]);
    return new A({
      ...this._def,
      shape: () => r
    });
  }
  omit(e) {
    const r = {};
    for (const n of E.objectKeys(this.shape))
      e[n] || (r[n] = this.shape[n]);
    return new A({
      ...this._def,
      shape: () => r
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return pe(this);
  }
  partial(e) {
    const r = {};
    for (const n of E.objectKeys(this.shape)) {
      const s = this.shape[n];
      e && !e[n] ? r[n] = s : r[n] = s.optional();
    }
    return new A({
      ...this._def,
      shape: () => r
    });
  }
  required(e) {
    const r = {};
    for (const n of E.objectKeys(this.shape))
      if (e && !e[n])
        r[n] = this.shape[n];
      else {
        let i = this.shape[n];
        for (; i instanceof U; )
          i = i._def.innerType;
        r[n] = i;
      }
    return new A({
      ...this._def,
      shape: () => r
    });
  }
  keyof() {
    return $t(E.objectKeys(this.shape));
  }
}
A.create = (t, e) => new A({
  shape: () => t,
  unknownKeys: "strip",
  catchall: ne.create(),
  typeName: w.ZodObject,
  ...x(e)
});
A.strictCreate = (t, e) => new A({
  shape: () => t,
  unknownKeys: "strict",
  catchall: ne.create(),
  typeName: w.ZodObject,
  ...x(e)
});
A.lazycreate = (t, e) => new A({
  shape: t,
  unknownKeys: "strip",
  catchall: ne.create(),
  typeName: w.ZodObject,
  ...x(e)
});
class Re extends S {
  _parse(e) {
    const { ctx: r } = this._processInputParams(e), n = this._def.options;
    function s(i) {
      for (const o of i)
        if (o.result.status === "valid")
          return o.result;
      for (const o of i)
        if (o.result.status === "dirty")
          return r.common.issues.push(...o.ctx.common.issues), o.result;
      const d = i.map((o) => new Z(o.ctx.common.issues));
      return h(r, {
        code: u.invalid_union,
        unionErrors: d
      }), k;
    }
    if (r.common.async)
      return Promise.all(n.map(async (i) => {
        const d = {
          ...r,
          common: {
            ...r.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await i._parseAsync({
            data: r.data,
            path: r.path,
            parent: d
          }),
          ctx: d
        };
      })).then(s);
    {
      let i;
      const d = [];
      for (const p of n) {
        const l = {
          ...r,
          common: {
            ...r.common,
            issues: []
          },
          parent: null
        }, m = p._parseSync({
          data: r.data,
          path: r.path,
          parent: l
        });
        if (m.status === "valid")
          return m;
        m.status === "dirty" && !i && (i = { result: m, ctx: l }), l.common.issues.length && d.push(l.common.issues);
      }
      if (i)
        return r.common.issues.push(...i.ctx.common.issues), i.result;
      const o = d.map((p) => new Z(p));
      return h(r, {
        code: u.invalid_union,
        unionErrors: o
      }), k;
    }
  }
  get options() {
    return this._def.options;
  }
}
Re.create = (t, e) => new Re({
  options: t,
  typeName: w.ZodUnion,
  ...x(e)
});
const Q = (t) => t instanceof Oe ? Q(t.schema) : t instanceof X ? Q(t.innerType()) : t instanceof Me ? [t.value] : t instanceof se ? t.options : t instanceof nt ? E.objectValues(t.enum) : t instanceof Ne ? Q(t._def.innerType) : t instanceof Ze ? [void 0] : t instanceof Ee ? [null] : t instanceof U ? [void 0, ...Q(t.unwrap())] : t instanceof ie ? [null, ...Q(t.unwrap())] : t instanceof ct || t instanceof Le ? Q(t.unwrap()) : t instanceof $e ? Q(t._def.innerType) : [];
class ze extends S {
  _parse(e) {
    const { ctx: r } = this._processInputParams(e);
    if (r.parsedType !== g.object)
      return h(r, {
        code: u.invalid_type,
        expected: g.object,
        received: r.parsedType
      }), k;
    const n = this.discriminator, s = r.data[n], i = this.optionsMap.get(s);
    return i ? r.common.async ? i._parseAsync({
      data: r.data,
      path: r.path,
      parent: r
    }) : i._parseSync({
      data: r.data,
      path: r.path,
      parent: r
    }) : (h(r, {
      code: u.invalid_union_discriminator,
      options: Array.from(this.optionsMap.keys()),
      path: [n]
    }), k);
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(e, r, n) {
    const s = /* @__PURE__ */ new Map();
    for (const i of r) {
      const d = Q(i.shape[e]);
      if (!d.length)
        throw new Error(`A discriminator value for key \`${e}\` could not be extracted from all schema options`);
      for (const o of d) {
        if (s.has(o))
          throw new Error(`Discriminator property ${String(e)} has duplicate value ${String(o)}`);
        s.set(o, i);
      }
    }
    return new ze({
      typeName: w.ZodDiscriminatedUnion,
      discriminator: e,
      options: r,
      optionsMap: s,
      ...x(n)
    });
  }
}
function tt(t, e) {
  const r = re(t), n = re(e);
  if (t === e)
    return { valid: !0, data: t };
  if (r === g.object && n === g.object) {
    const s = E.objectKeys(e), i = E.objectKeys(t).filter((o) => s.indexOf(o) !== -1), d = { ...t, ...e };
    for (const o of i) {
      const p = tt(t[o], e[o]);
      if (!p.valid)
        return { valid: !1 };
      d[o] = p.data;
    }
    return { valid: !0, data: d };
  } else if (r === g.array && n === g.array) {
    if (t.length !== e.length)
      return { valid: !1 };
    const s = [];
    for (let i = 0; i < t.length; i++) {
      const d = t[i], o = e[i], p = tt(d, o);
      if (!p.valid)
        return { valid: !1 };
      s.push(p.data);
    }
    return { valid: !0, data: s };
  } else return r === g.date && n === g.date && +t == +e ? { valid: !0, data: t } : { valid: !1 };
}
class Ce extends S {
  _parse(e) {
    const { status: r, ctx: n } = this._processInputParams(e), s = (i, d) => {
      if (vt(i) || vt(d))
        return k;
      const o = tt(i.value, d.value);
      return o.valid ? ((kt(i) || kt(d)) && r.dirty(), { status: r.value, value: o.data }) : (h(n, {
        code: u.invalid_intersection_types
      }), k);
    };
    return n.common.async ? Promise.all([
      this._def.left._parseAsync({
        data: n.data,
        path: n.path,
        parent: n
      }),
      this._def.right._parseAsync({
        data: n.data,
        path: n.path,
        parent: n
      })
    ]).then(([i, d]) => s(i, d)) : s(this._def.left._parseSync({
      data: n.data,
      path: n.path,
      parent: n
    }), this._def.right._parseSync({
      data: n.data,
      path: n.path,
      parent: n
    }));
  }
}
Ce.create = (t, e, r) => new Ce({
  left: t,
  right: e,
  typeName: w.ZodIntersection,
  ...x(r)
});
class G extends S {
  _parse(e) {
    const { status: r, ctx: n } = this._processInputParams(e);
    if (n.parsedType !== g.array)
      return h(n, {
        code: u.invalid_type,
        expected: g.array,
        received: n.parsedType
      }), k;
    if (n.data.length < this._def.items.length)
      return h(n, {
        code: u.too_small,
        minimum: this._def.items.length,
        inclusive: !0,
        exact: !1,
        type: "array"
      }), k;
    !this._def.rest && n.data.length > this._def.items.length && (h(n, {
      code: u.too_big,
      maximum: this._def.items.length,
      inclusive: !0,
      exact: !1,
      type: "array"
    }), r.dirty());
    const i = [...n.data].map((d, o) => {
      const p = this._def.items[o] || this._def.rest;
      return p ? p._parse(new H(n, d, n.path, o)) : null;
    }).filter((d) => !!d);
    return n.common.async ? Promise.all(i).then((d) => L.mergeArray(r, d)) : L.mergeArray(r, i);
  }
  get items() {
    return this._def.items;
  }
  rest(e) {
    return new G({
      ...this._def,
      rest: e
    });
  }
}
G.create = (t, e) => {
  if (!Array.isArray(t))
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  return new G({
    items: t,
    typeName: w.ZodTuple,
    rest: null,
    ...x(e)
  });
};
class Ae extends S {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(e) {
    const { status: r, ctx: n } = this._processInputParams(e);
    if (n.parsedType !== g.object)
      return h(n, {
        code: u.invalid_type,
        expected: g.object,
        received: n.parsedType
      }), k;
    const s = [], i = this._def.keyType, d = this._def.valueType;
    for (const o in n.data)
      s.push({
        key: i._parse(new H(n, o, n.path, o)),
        value: d._parse(new H(n, n.data[o], n.path, o)),
        alwaysSet: o in n.data
      });
    return n.common.async ? L.mergeObjectAsync(r, s) : L.mergeObjectSync(r, s);
  }
  get element() {
    return this._def.valueType;
  }
  static create(e, r, n) {
    return r instanceof S ? new Ae({
      keyType: e,
      valueType: r,
      typeName: w.ZodRecord,
      ...x(n)
    }) : new Ae({
      keyType: q.create(),
      valueType: e,
      typeName: w.ZodRecord,
      ...x(r)
    });
  }
}
class rt extends S {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(e) {
    const { status: r, ctx: n } = this._processInputParams(e);
    if (n.parsedType !== g.map)
      return h(n, {
        code: u.invalid_type,
        expected: g.map,
        received: n.parsedType
      }), k;
    const s = this._def.keyType, i = this._def.valueType, d = [...n.data.entries()].map(([o, p], l) => ({
      key: s._parse(new H(n, o, n.path, [l, "key"])),
      value: i._parse(new H(n, p, n.path, [l, "value"]))
    }));
    if (n.common.async) {
      const o = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const p of d) {
          const l = await p.key, m = await p.value;
          if (l.status === "aborted" || m.status === "aborted")
            return k;
          (l.status === "dirty" || m.status === "dirty") && r.dirty(), o.set(l.value, m.value);
        }
        return { status: r.value, value: o };
      });
    } else {
      const o = /* @__PURE__ */ new Map();
      for (const p of d) {
        const l = p.key, m = p.value;
        if (l.status === "aborted" || m.status === "aborted")
          return k;
        (l.status === "dirty" || m.status === "dirty") && r.dirty(), o.set(l.value, m.value);
      }
      return { status: r.value, value: o };
    }
  }
}
rt.create = (t, e, r) => new rt({
  valueType: e,
  keyType: t,
  typeName: w.ZodMap,
  ...x(r)
});
class ye extends S {
  _parse(e) {
    const { status: r, ctx: n } = this._processInputParams(e);
    if (n.parsedType !== g.set)
      return h(n, {
        code: u.invalid_type,
        expected: g.set,
        received: n.parsedType
      }), k;
    const s = this._def;
    s.minSize !== null && n.data.size < s.minSize.value && (h(n, {
      code: u.too_small,
      minimum: s.minSize.value,
      type: "set",
      inclusive: !0,
      exact: !1,
      message: s.minSize.message
    }), r.dirty()), s.maxSize !== null && n.data.size > s.maxSize.value && (h(n, {
      code: u.too_big,
      maximum: s.maxSize.value,
      type: "set",
      inclusive: !0,
      exact: !1,
      message: s.maxSize.message
    }), r.dirty());
    const i = this._def.valueType;
    function d(p) {
      const l = /* @__PURE__ */ new Set();
      for (const m of p) {
        if (m.status === "aborted")
          return k;
        m.status === "dirty" && r.dirty(), l.add(m.value);
      }
      return { status: r.value, value: l };
    }
    const o = [...n.data.values()].map((p, l) => i._parse(new H(n, p, n.path, l)));
    return n.common.async ? Promise.all(o).then((p) => d(p)) : d(o);
  }
  min(e, r) {
    return new ye({
      ...this._def,
      minSize: { value: e, message: y.toString(r) }
    });
  }
  max(e, r) {
    return new ye({
      ...this._def,
      maxSize: { value: e, message: y.toString(r) }
    });
  }
  size(e, r) {
    return this.min(e, r).max(e, r);
  }
  nonempty(e) {
    return this.min(1, e);
  }
}
ye.create = (t, e) => new ye({
  valueType: t,
  minSize: null,
  maxSize: null,
  typeName: w.ZodSet,
  ...x(e)
});
class xe extends S {
  constructor() {
    super(...arguments), this.validate = this.implement;
  }
  _parse(e) {
    const { ctx: r } = this._processInputParams(e);
    if (r.parsedType !== g.function)
      return h(r, {
        code: u.invalid_type,
        expected: g.function,
        received: r.parsedType
      }), k;
    function n(o, p) {
      return Qe({
        data: o,
        path: r.path,
        errorMaps: [r.common.contextualErrorMap, r.schemaErrorMap, Ke(), Se].filter((l) => !!l),
        issueData: {
          code: u.invalid_arguments,
          argumentsError: p
        }
      });
    }
    function s(o, p) {
      return Qe({
        data: o,
        path: r.path,
        errorMaps: [r.common.contextualErrorMap, r.schemaErrorMap, Ke(), Se].filter((l) => !!l),
        issueData: {
          code: u.invalid_return_type,
          returnTypeError: p
        }
      });
    }
    const i = { errorMap: r.common.contextualErrorMap }, d = r.data;
    if (this._def.returns instanceof be) {
      const o = this;
      return P(async function(...p) {
        const l = new Z([]), m = await o._def.args.parseAsync(p, i).catch((te) => {
          throw l.addIssue(n(p, te)), l;
        }), R = await Reflect.apply(d, this, m);
        return await o._def.returns._def.type.parseAsync(R, i).catch((te) => {
          throw l.addIssue(s(R, te)), l;
        });
      });
    } else {
      const o = this;
      return P(function(...p) {
        const l = o._def.args.safeParse(p, i);
        if (!l.success)
          throw new Z([n(p, l.error)]);
        const m = Reflect.apply(d, this, l.data), R = o._def.returns.safeParse(m, i);
        if (!R.success)
          throw new Z([s(m, R.error)]);
        return R.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...e) {
    return new xe({
      ...this._def,
      args: G.create(e).rest(ae.create())
    });
  }
  returns(e) {
    return new xe({
      ...this._def,
      returns: e
    });
  }
  implement(e) {
    return this.parse(e);
  }
  strictImplement(e) {
    return this.parse(e);
  }
  static create(e, r, n) {
    return new xe({
      args: e || G.create([]).rest(ae.create()),
      returns: r || ae.create(),
      typeName: w.ZodFunction,
      ...x(n)
    });
  }
}
class Oe extends S {
  get schema() {
    return this._def.getter();
  }
  _parse(e) {
    const { ctx: r } = this._processInputParams(e);
    return this._def.getter()._parse({ data: r.data, path: r.path, parent: r });
  }
}
Oe.create = (t, e) => new Oe({
  getter: t,
  typeName: w.ZodLazy,
  ...x(e)
});
class Me extends S {
  _parse(e) {
    if (e.data !== this._def.value) {
      const r = this._getOrReturnCtx(e);
      return h(r, {
        received: r.data,
        code: u.invalid_literal,
        expected: this._def.value
      }), k;
    }
    return { status: "valid", value: e.data };
  }
  get value() {
    return this._def.value;
  }
}
Me.create = (t, e) => new Me({
  value: t,
  typeName: w.ZodLiteral,
  ...x(e)
});
function $t(t, e) {
  return new se({
    values: t,
    typeName: w.ZodEnum,
    ...x(e)
  });
}
class se extends S {
  _parse(e) {
    if (typeof e.data != "string") {
      const r = this._getOrReturnCtx(e), n = this._def.values;
      return h(r, {
        expected: E.joinValues(n),
        received: r.parsedType,
        code: u.invalid_type
      }), k;
    }
    if (this._cache || (this._cache = new Set(this._def.values)), !this._cache.has(e.data)) {
      const r = this._getOrReturnCtx(e), n = this._def.values;
      return h(r, {
        received: r.data,
        code: u.invalid_enum_value,
        options: n
      }), k;
    }
    return P(e.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const e = {};
    for (const r of this._def.values)
      e[r] = r;
    return e;
  }
  get Values() {
    const e = {};
    for (const r of this._def.values)
      e[r] = r;
    return e;
  }
  get Enum() {
    const e = {};
    for (const r of this._def.values)
      e[r] = r;
    return e;
  }
  extract(e, r = this._def) {
    return se.create(e, {
      ...this._def,
      ...r
    });
  }
  exclude(e, r = this._def) {
    return se.create(this.options.filter((n) => !e.includes(n)), {
      ...this._def,
      ...r
    });
  }
}
se.create = $t;
class nt extends S {
  _parse(e) {
    const r = E.getValidEnumValues(this._def.values), n = this._getOrReturnCtx(e);
    if (n.parsedType !== g.string && n.parsedType !== g.number) {
      const s = E.objectValues(r);
      return h(n, {
        expected: E.joinValues(s),
        received: n.parsedType,
        code: u.invalid_type
      }), k;
    }
    if (this._cache || (this._cache = new Set(E.getValidEnumValues(this._def.values))), !this._cache.has(e.data)) {
      const s = E.objectValues(r);
      return h(n, {
        received: n.data,
        code: u.invalid_enum_value,
        options: s
      }), k;
    }
    return P(e.data);
  }
  get enum() {
    return this._def.values;
  }
}
nt.create = (t, e) => new nt({
  values: t,
  typeName: w.ZodNativeEnum,
  ...x(e)
});
class be extends S {
  unwrap() {
    return this._def.type;
  }
  _parse(e) {
    const { ctx: r } = this._processInputParams(e);
    if (r.parsedType !== g.promise && r.common.async === !1)
      return h(r, {
        code: u.invalid_type,
        expected: g.promise,
        received: r.parsedType
      }), k;
    const n = r.parsedType === g.promise ? r.data : Promise.resolve(r.data);
    return P(n.then((s) => this._def.type.parseAsync(s, {
      path: r.path,
      errorMap: r.common.contextualErrorMap
    })));
  }
}
be.create = (t, e) => new be({
  type: t,
  typeName: w.ZodPromise,
  ...x(e)
});
class X extends S {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === w.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(e) {
    const { status: r, ctx: n } = this._processInputParams(e), s = this._def.effect || null, i = {
      addIssue: (d) => {
        h(n, d), d.fatal ? r.abort() : r.dirty();
      },
      get path() {
        return n.path;
      }
    };
    if (i.addIssue = i.addIssue.bind(i), s.type === "preprocess") {
      const d = s.transform(n.data, i);
      if (n.common.async)
        return Promise.resolve(d).then(async (o) => {
          if (r.value === "aborted")
            return k;
          const p = await this._def.schema._parseAsync({
            data: o,
            path: n.path,
            parent: n
          });
          return p.status === "aborted" ? k : p.status === "dirty" || r.value === "dirty" ? ke(p.value) : p;
        });
      {
        if (r.value === "aborted")
          return k;
        const o = this._def.schema._parseSync({
          data: d,
          path: n.path,
          parent: n
        });
        return o.status === "aborted" ? k : o.status === "dirty" || r.value === "dirty" ? ke(o.value) : o;
      }
    }
    if (s.type === "refinement") {
      const d = (o) => {
        const p = s.refinement(o, i);
        if (n.common.async)
          return Promise.resolve(p);
        if (p instanceof Promise)
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        return o;
      };
      if (n.common.async === !1) {
        const o = this._def.schema._parseSync({
          data: n.data,
          path: n.path,
          parent: n
        });
        return o.status === "aborted" ? k : (o.status === "dirty" && r.dirty(), d(o.value), { status: r.value, value: o.value });
      } else
        return this._def.schema._parseAsync({ data: n.data, path: n.path, parent: n }).then((o) => o.status === "aborted" ? k : (o.status === "dirty" && r.dirty(), d(o.value).then(() => ({ status: r.value, value: o.value }))));
    }
    if (s.type === "transform")
      if (n.common.async === !1) {
        const d = this._def.schema._parseSync({
          data: n.data,
          path: n.path,
          parent: n
        });
        if (!ge(d))
          return k;
        const o = s.transform(d.value, i);
        if (o instanceof Promise)
          throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");
        return { status: r.value, value: o };
      } else
        return this._def.schema._parseAsync({ data: n.data, path: n.path, parent: n }).then((d) => ge(d) ? Promise.resolve(s.transform(d.value, i)).then((o) => ({
          status: r.value,
          value: o
        })) : k);
    E.assertNever(s);
  }
}
X.create = (t, e, r) => new X({
  schema: t,
  typeName: w.ZodEffects,
  effect: e,
  ...x(r)
});
X.createWithPreprocess = (t, e, r) => new X({
  schema: e,
  effect: { type: "preprocess", transform: t },
  typeName: w.ZodEffects,
  ...x(r)
});
class U extends S {
  _parse(e) {
    return this._getType(e) === g.undefined ? P(void 0) : this._def.innerType._parse(e);
  }
  unwrap() {
    return this._def.innerType;
  }
}
U.create = (t, e) => new U({
  innerType: t,
  typeName: w.ZodOptional,
  ...x(e)
});
class ie extends S {
  _parse(e) {
    return this._getType(e) === g.null ? P(null) : this._def.innerType._parse(e);
  }
  unwrap() {
    return this._def.innerType;
  }
}
ie.create = (t, e) => new ie({
  innerType: t,
  typeName: w.ZodNullable,
  ...x(e)
});
class Ne extends S {
  _parse(e) {
    const { ctx: r } = this._processInputParams(e);
    let n = r.data;
    return r.parsedType === g.undefined && (n = this._def.defaultValue()), this._def.innerType._parse({
      data: n,
      path: r.path,
      parent: r
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
}
Ne.create = (t, e) => new Ne({
  innerType: t,
  typeName: w.ZodDefault,
  defaultValue: typeof e.default == "function" ? e.default : () => e.default,
  ...x(e)
});
class $e extends S {
  _parse(e) {
    const { ctx: r } = this._processInputParams(e), n = {
      ...r,
      common: {
        ...r.common,
        issues: []
      }
    }, s = this._def.innerType._parse({
      data: n.data,
      path: n.path,
      parent: {
        ...n
      }
    });
    return je(s) ? s.then((i) => ({
      status: "valid",
      value: i.status === "valid" ? i.value : this._def.catchValue({
        get error() {
          return new Z(n.common.issues);
        },
        input: n.data
      })
    })) : {
      status: "valid",
      value: s.status === "valid" ? s.value : this._def.catchValue({
        get error() {
          return new Z(n.common.issues);
        },
        input: n.data
      })
    };
  }
  removeCatch() {
    return this._def.innerType;
  }
}
$e.create = (t, e) => new $e({
  innerType: t,
  typeName: w.ZodCatch,
  catchValue: typeof e.catch == "function" ? e.catch : () => e.catch,
  ...x(e)
});
class st extends S {
  _parse(e) {
    if (this._getType(e) !== g.nan) {
      const n = this._getOrReturnCtx(e);
      return h(n, {
        code: u.invalid_type,
        expected: g.nan,
        received: n.parsedType
      }), k;
    }
    return { status: "valid", value: e.data };
  }
}
st.create = (t) => new st({
  typeName: w.ZodNaN,
  ...x(t)
});
class ct extends S {
  _parse(e) {
    const { ctx: r } = this._processInputParams(e), n = r.data;
    return this._def.type._parse({
      data: n,
      path: r.path,
      parent: r
    });
  }
  unwrap() {
    return this._def.type;
  }
}
class qe extends S {
  _parse(e) {
    const { status: r, ctx: n } = this._processInputParams(e);
    if (n.common.async)
      return (async () => {
        const i = await this._def.in._parseAsync({
          data: n.data,
          path: n.path,
          parent: n
        });
        return i.status === "aborted" ? k : i.status === "dirty" ? (r.dirty(), ke(i.value)) : this._def.out._parseAsync({
          data: i.value,
          path: n.path,
          parent: n
        });
      })();
    {
      const s = this._def.in._parseSync({
        data: n.data,
        path: n.path,
        parent: n
      });
      return s.status === "aborted" ? k : s.status === "dirty" ? (r.dirty(), {
        status: "dirty",
        value: s.value
      }) : this._def.out._parseSync({
        data: s.value,
        path: n.path,
        parent: n
      });
    }
  }
  static create(e, r) {
    return new qe({
      in: e,
      out: r,
      typeName: w.ZodPipeline
    });
  }
}
class Le extends S {
  _parse(e) {
    const r = this._def.innerType._parse(e), n = (s) => (ge(s) && (s.value = Object.freeze(s.value)), s);
    return je(r) ? r.then((s) => n(s)) : n(r);
  }
  unwrap() {
    return this._def.innerType;
  }
}
Le.create = (t, e) => new Le({
  innerType: t,
  typeName: w.ZodReadonly,
  ...x(e)
});
var w;
(function(t) {
  t.ZodString = "ZodString", t.ZodNumber = "ZodNumber", t.ZodNaN = "ZodNaN", t.ZodBigInt = "ZodBigInt", t.ZodBoolean = "ZodBoolean", t.ZodDate = "ZodDate", t.ZodSymbol = "ZodSymbol", t.ZodUndefined = "ZodUndefined", t.ZodNull = "ZodNull", t.ZodAny = "ZodAny", t.ZodUnknown = "ZodUnknown", t.ZodNever = "ZodNever", t.ZodVoid = "ZodVoid", t.ZodArray = "ZodArray", t.ZodObject = "ZodObject", t.ZodUnion = "ZodUnion", t.ZodDiscriminatedUnion = "ZodDiscriminatedUnion", t.ZodIntersection = "ZodIntersection", t.ZodTuple = "ZodTuple", t.ZodRecord = "ZodRecord", t.ZodMap = "ZodMap", t.ZodSet = "ZodSet", t.ZodFunction = "ZodFunction", t.ZodLazy = "ZodLazy", t.ZodLiteral = "ZodLiteral", t.ZodEnum = "ZodEnum", t.ZodEffects = "ZodEffects", t.ZodNativeEnum = "ZodNativeEnum", t.ZodOptional = "ZodOptional", t.ZodNullable = "ZodNullable", t.ZodDefault = "ZodDefault", t.ZodCatch = "ZodCatch", t.ZodPromise = "ZodPromise", t.ZodBranded = "ZodBranded", t.ZodPipeline = "ZodPipeline", t.ZodReadonly = "ZodReadonly";
})(w || (w = {}));
const a = q.create, f = oe.create, Y = de.create, b = De.create, Lt = Ee.create, v = ae.create;
ne.create;
const I = F.create, c = A.create, T = Re.create, $r = ze.create;
Ce.create;
const Lr = G.create, _ = Ae.create, Pr = Oe.create, Te = Me.create, _e = se.create;
be.create;
U.create;
ie.create;
const ee = X.createWithPreprocess;
function N(t, e = 0, r = 2) {
  if (e > r) return "...";
  if (t instanceof A) {
    const n = t.shape, s = Object.keys(n).filter((d) => !d.startsWith("__"));
    return s.length === 0 ? "{ }" : e >= r - 1 ? "{ ... }" : `{ ${s.map((d) => {
      const o = n[d], p = o instanceof U, l = N(p ? o.unwrap() : o, e + 1, r);
      return `${d}${p ? "?" : ""}: ${l}`;
    }).join(", ")} }`;
  }
  if (t instanceof Re)
    return t.options.map((n) => N(n, e, r)).join(" or ");
  if (t instanceof q) return "string";
  if (t instanceof oe) return "number";
  if (t instanceof De) return "boolean";
  if (t instanceof de) return "bigint";
  if (t instanceof Ee) return "null";
  if (t instanceof F) {
    const n = N(t.element, e + 1, r);
    return n === "unknown" || n === "any" ? "array" : `${n}[]`;
  }
  if (t instanceof G)
    return `[${t.items.map((n) => N(n, e + 1, r)).join(", ")}]`;
  if (t instanceof Ae) {
    const n = N(
      t._def.valueType,
      e + 1,
      r
    );
    return n === "unknown" || n === "any" ? "{ [key: string]: unknown }" : `{ [key: string]: ${n} }`;
  }
  return t instanceof U ? `${N(t.unwrap(), e, r)}?` : t instanceof Me ? JSON.stringify(t.value) : t instanceof se ? t.options.map((n) => `"${n}"`).join(" | ") : t instanceof Xe ? "any" : t instanceof ae ? "unknown" : t instanceof et ? "void" : t instanceof Ze ? "undefined" : t instanceof X ? N(t.innerType(), e, r) : t instanceof Ne ? N(t.removeDefault(), e, r) : t instanceof ie ? `${N(t.unwrap(), e, r)} | null` : t instanceof Oe ? "lazy" : t instanceof be ? `Promise<${N(t.unwrap(), e + 1, r)}>` : t instanceof xe ? "function" : t instanceof Ie ? "Date" : t instanceof rt ? "Map" : t instanceof ye ? "Set" : t instanceof Ce ? `${N(t._def.left, e, r)} & ${N(t._def.right, e, r)}` : t instanceof ze ? t.options.map((n) => N(n, e, r)).join(" or ") : t instanceof ct ? N(t.unwrap(), e, r) : t instanceof st ? "NaN" : t instanceof $e ? N(t.removeCatch(), e, r) : t instanceof qe ? N(t._def.in, e, r) : t instanceof Le ? `readonly ${N(t.unwrap(), e, r)}` : "unknown";
}
function jr(t) {
  return t === null ? "null" : t === void 0 ? "undefined" : Array.isArray(t) ? "array" : typeof t;
}
function Dr(t, e, r, n) {
  const s = r.filter((o) => o.path.length === 0), i = r.filter((o) => o.path.length > 0);
  if (s.length > 0 && i.length === 0) {
    const o = s.some((l) => l.code === "custom"), p = s.some(
      (l) => l.code !== "invalid_type" && l.code !== "invalid_literal" && l.code !== "invalid_union"
    );
    if (!o && !p) {
      const l = N(e), m = jr(n);
      return `Invalid parameters for ${t}: expected ${l}${l === "{ }" ? " or no args" : ""}, received ${m}`;
    }
  }
  const d = r.map((o) => `at '${o.path.length > 0 ? o.path.join(".") : "root"}': ${o.message}`);
  return `Invalid parameters for ${t}: ${d.join("; ")}`;
}
_(v());
_(v());
_(v());
_(v());
T([
  f(),
  _(v())
]);
T([
  f(),
  _(v())
]);
_(v());
_(v());
_(v());
T([
  a(),
  _(v())
]);
_(v());
_(
  v()
);
_(v());
_(v());
_(v());
T([
  a(),
  f(),
  _(v())
]);
_(v());
_(v());
_(v());
T([
  f(),
  _(v())
]);
_(v());
_(v());
_(v());
_(v());
_(v());
I(v());
T([
  a(),
  _(v())
]);
_(v());
T([
  a(),
  _(v())
]);
_(v());
T([
  a(),
  _(v())
]);
_(v());
T([
  a(),
  _(v())
]);
_(v());
_(v());
T([
  f(),
  _(v())
]);
_(v());
_(v());
T([
  f(),
  _(v())
]);
_(
  v()
);
T([
  a(),
  f(),
  _(v())
]);
_(v());
_(v());
_(v());
_(v());
T([
  f(),
  _(v())
]);
T([
  f(),
  _(v())
]);
T([
  f(),
  _(v())
]);
T([
  f(),
  _(v())
]);
T([
  f(),
  _(v())
]);
_(v());
_(v());
_(v());
c({});
T([
  Lr([T([c({ text: a() }), a()])]),
  c({ text: a().optional(), value: a().optional() })
]);
const j = () => T([Y(), f().finite()]).transform((t) => BigInt(t)), J = () => a().regex(/^(?:f\d+_)?e\d+$/), Zr = 'use { refId: "e2" } or { label: "..." } object form, not positional arguments', lt = (t, e) => {
  if (t.__invalidPositional !== void 0) {
    e.addIssue({
      code: u.custom,
      message: Zr
    });
    return;
  }
  !t.refId && !t.label && e.addIssue({
    code: u.custom,
    message: "Either refId or label is required"
  });
}, Pt = (t, e) => {
  t.x !== void 0 || t.y !== void 0 || lt(t, e);
}, M = (t) => ee(
  (e) => typeof e == "string" || typeof e == "number" ? { __invalidPositional: e } : e,
  c({
    __invalidPositional: T([a(), f()]).optional().describe("Internal flag for positional argument rejection"),
    refId: J().optional().describe("Element reference ID (e.g. e2)"),
    label: a().optional().describe("Human-readable element label"),
    ...t
  }).superRefine(lt)
), le = {
  tabId: T([f(), Y()]).optional().describe("Target tab ID")
}, B = (t) => ee(
  (e) => typeof e == "string" || typeof e == "number" ? { __invalidPositional: e } : e,
  c({
    __invalidPositional: T([a(), f()]).optional().describe("Internal flag for positional argument rejection"),
    ...le,
    refId: J().optional().describe("Element reference ID (e.g. e2)"),
    label: a().optional().describe("Human-readable element label"),
    ...t
  }).superRefine(lt)
), D = c({
  path: a().describe("File or directory path")
}), Tt = c({
  from: a().describe("Source path"),
  to: a().describe("Destination path")
}), fe = c({
  path: a().describe("File path to write to"),
  data: a().describe("Data to write")
}), Wr = c({
  path: a().describe("File path to read from"),
  offset: j().describe("Byte offset to start reading"),
  len: f().describe("Number of bytes to read")
}), Vr = c({
  path: a().describe("File path to update"),
  offset: j().describe("Byte offset to start writing"),
  data: a().describe("Data to write")
}), Fr = c({
  path: a().describe("File path to hash"),
  algo: a().default("sha256").describe("Hash algorithm (e.g. sha256, md5)")
});
c({
  action: a().describe("Host action name"),
  params: c({}).passthrough().optional().describe("Parameters for the host action")
}).passthrough();
T([
  a(),
  f(),
  b(),
  Lt(),
  I(v()),
  _(v())
]);
c({
  url: a().describe("URL to fetch"),
  method: a().default("GET").describe("HTTP method (GET, POST, PUT, DELETE, etc.)"),
  headers: _(a()).default({}).describe("Request headers as key-value pairs"),
  body: a().nullable().default(null).describe("Request body string"),
  timeout: j().default(30000n).describe("Timeout in milliseconds"),
  store: b().optional().describe(
    "When true, store binary responses as a handle instead of returning body bytes"
  ),
  options: c({}).passthrough().optional().describe("Fetch options")
}).passthrough();
c({
  duration: j().describe("Duration to sleep in milliseconds")
});
c({});
c({});
c({
  url: a().describe("URL to navigate to"),
  timeout: j().optional().describe("Navigation timeout in milliseconds"),
  waitUntil: _e(["load", "networkidle"]).optional().describe(
    "When to consider navigation complete: 'load' (tab status complete) or 'networkidle' (no in-flight requests for 500ms)"
  )
});
c({});
c({});
c({});
c({
  duration: j().default(1000n).describe("Duration to wait in milliseconds")
});
M();
const Ur = (t, e) => {
  [t.url, t.path, t.handle].filter(
    (n) => typeof n == "string" && n.length > 0
  ).length !== 1 && e.addIssue({
    code: u.custom,
    message: "Each file entry requires exactly one of url, path, or handle"
  });
}, jt = c({
  name: a().optional().describe("File name including extension"),
  mimeType: a().optional().describe("MIME type (defaults to application/octet-stream)"),
  url: a().url().optional().describe("HTTP(S) URL to fetch in the target tab"),
  path: a().min(1).optional().describe("Virtual filesystem path (resolved in worker)"),
  handle: a().min(1).optional().describe("Binary handle from page.fetch({ store: true })")
}).superRefine(Ur), Dt = $r("kind", [
  c({
    kind: Te("bytes"),
    name: a().min(1),
    data: a().min(1),
    mimeType: a().optional()
  }),
  c({
    kind: Te("url"),
    url: a().url(),
    name: a().min(1),
    mimeType: a().optional()
  })
]);
M({
  value: a().describe("Value to fill into the element")
});
const Br = M({
  files: I(jt).min(1).describe("Files to attach to the input")
});
M({
  files: I(Dt).min(1).describe("Resolved files for content-script application")
});
M({
  text: a().describe("Text to type into the element")
});
M({
  text: a().describe("Text to append into the element")
});
c({
  refId: J().optional().describe(
    "Element reference ID to dispatch the key on (e.g. e2). Omit to dispatch on document."
  ),
  label: a().optional().describe("Human-readable element label. Omit to dispatch on document."),
  key: a().describe("Key to press (e.g. Enter, Escape, ArrowDown)")
});
M({
  value: T([
    a().describe("Value to select in the dropdown"),
    I(a()).describe(
      "Values to select in a multiple dropdown (empty array clears selection)"
    )
  ]).describe("Value (string) or values (array) to select in the dropdown")
});
M({
  value: a().describe(
    "Visible text of the option to select (matched case-insensitively)"
  )
});
M({
  checked: b().optional().describe("Desired checked state (true to check, false to uncheck)")
});
c({
  name: a().min(1).describe("The `name` attribute of the radio group to pick from"),
  value: a().describe("The `value` of the radio option to check")
});
M();
c({});
M();
c({
  direction: a().default("down").describe("Scroll direction: up, down, left, or right"),
  amount: f().default(300).describe("Pixels to scroll")
});
ee(
  (t) => typeof t == "string" || typeof t == "number" ? { __invalidPositional: t } : t,
  c({
    __invalidPositional: T([a(), f()]).optional().describe("Internal flag for positional argument rejection"),
    refId: J().optional().describe("Element reference ID (e.g. e2)"),
    label: a().optional().describe("Human-readable element label"),
    x: f().optional().describe("X coordinate to scroll to"),
    y: f().optional().describe("Y coordinate to scroll to")
  }).superRefine(Pt)
);
M();
c({
  selector: a().describe("CSS selector to find elements")
});
c({
  selector: a().describe("CSS selector for the root element(s) to introspect"),
  depth: f().int().min(0).max(10).default(2).describe("How many descendant levels to include (0 = root only)"),
  includeHidden: b().default(!0).describe(
    "Include elements hidden by CSS/aria (default true — this tool's purpose is to see what the curated snapshot filters out)"
  )
});
c({
  selector: a().describe("CSS selector to wait for"),
  timeout: j().default(30000n).describe("Timeout in milliseconds")
});
const zr = c({
  fields: I(a()).describe("Array of field names to extract")
});
ee(
  (t) => Array.isArray(t) ? { fields: t } : t,
  zr
);
T([
  f(),
  I(c({}).passthrough()),
  c({}).passthrough()
]);
c({});
const qr = c({
  ok: Te(!0).describe("Whether the action succeeded"),
  action: a().describe("Action identifier (e.g. 'page_fill')"),
  refId: J().optional().describe("Element reference ID that was acted upon (e.g. e2)"),
  tag: a().optional().describe("HTML tag name of the element"),
  role: a().optional().describe("ARIA role of the element"),
  name: a().optional().describe("Accessible name of the element"),
  value: T([a(), I(a())]).optional().describe(
    "Final value of the element after the action (string, or string[] for multi-select)"
  ),
  checked: b().optional().describe("Checked state after the action"),
  disabled: b().optional().describe("Whether the element is disabled"),
  readOnly: b().optional().describe("Whether the element is read-only"),
  required: b().optional().describe("Whether the element is required"),
  valid: b().optional().describe("HTML constraint validity after the action, when available"),
  invalid: b().optional().describe("Inverse validity / aria-invalid state after the action"),
  validationMessage: a().optional().describe("Browser validation message when the element is invalid"),
  invalidControls: I(
    c({
      refId: J().optional(),
      tag: a(),
      role: a().optional(),
      name: a().optional(),
      field: a().optional().describe("Accessible field label or nearest label text"),
      error: a().optional().describe(
        "Linked visible error text from aria-errormessage/aria-describedby"
      ),
      value: a().optional(),
      required: b().optional(),
      validationMessage: a().optional()
    })
  ).optional().describe("Invalid form controls after submit, when available"),
  text: a().optional().describe("Text content of the element"),
  selectedText: a().optional().describe("Visible option text selected by select_option"),
  key: a().optional().describe("Key that was pressed (for press actions)"),
  direction: a().optional().describe("Scroll direction (for scroll actions)"),
  amount: f().optional().describe("Scroll amount in pixels (for scroll actions)"),
  fileCount: f().optional().describe("Number of files attached (for setFiles actions)"),
  fileNames: I(a()).optional().describe("Names of attached files (for setFiles actions)"),
  observationId: a().optional().describe(
    "Opaque ID of the observation lease authorizing this action (snapshot-scoped)"
  ),
  dispatched: Te(!0).optional().describe(
    "True if the action was dispatched to the DOM. Does NOT prove the application accepted it."
  ),
  verification: Te("required").optional().describe(
    "Always 'required': a fresh observation is required to verify the effect."
  )
});
T([qr, Lt()]);
c({
  status: f().describe("HTTP response status code"),
  ok: b().describe("Whether the response status is 2xx"),
  headers: _(a()).describe("Response headers as key-value pairs"),
  body: a().optional().describe("Response body (omitted when bodyEncoding is handle)"),
  bodyEncoding: _e(["text", "base64", "handle"]).describe("Encoding of the body field"),
  handle: a().optional().describe("Binary handle when bodyEncoding is handle"),
  byteLength: f().describe("Length of the body in bytes"),
  contentType: a().describe("Response Content-Type header"),
  finalUrl: a().describe("Final URL after redirects")
});
c({
  data: c({}).passthrough().describe("Structured snapshot data"),
  text: a().describe("Plain text representation of the snapshot")
});
c({});
c({
  tabId: f(),
  url: a(),
  title: a(),
  contentScript: _e(["connected", "missing"]),
  domApis: _e(["ok", "blocked"]),
  mutationsReady: b(),
  hint: a().optional(),
  recovery: I(a()).optional()
});
const Hr = c({
  refId: J().describe("Element reference ID (e.g. e2)"),
  role: a().describe("ARIA role of the element"),
  tag: a().describe("HTML tag name"),
  controlType: a().optional().describe(
    'Plain-language control type, e.g. "dropdown" for combobox/select'
  ),
  actionable: b().optional().describe("Whether this node can be acted on directly"),
  forControl: a().optional().describe("refId of the dropdown this validation-proxy belongs to"),
  recommendedAction: a().optional().describe("Recommended page.* action for this control"),
  controls: a().optional().describe("ID(s) of controlled popup/listbox elements, when exposed"),
  expanded: b().optional().describe("Expanded state for popup controls"),
  name: a().optional().describe("Accessible name of the element"),
  text: a().optional().describe("Visible text content of the element"),
  value: a().optional().describe("Element value"),
  required: b().optional().describe("Whether the element is required"),
  valid: b().optional().describe("Constraint validity state"),
  invalid: b().optional().describe("Constraint invalidity state"),
  validationMessage: a().optional().describe("Browser constraint validation message"),
  errorMessage: a().optional().describe("Visible error text linked to the field"),
  checked: b().optional().describe("Checked state"),
  disabled: b().optional().describe("Whether the element is disabled"),
  readOnly: b().optional().describe("Whether the element is read-only"),
  selected: b().optional().describe("For <option>: selected state"),
  href: a().optional().describe("Absolute URL for link elements"),
  src: a().optional().describe("Absolute URL for image elements"),
  alt: a().optional().describe("Alternative text for image elements"),
  title: a().optional().describe("Title attribute"),
  parentRefId: J().optional().describe("Reference ID of the parent container element"),
  postId: a().optional().describe("Stable post identifier from data-post-id attribute"),
  permalink: a().optional().describe("Stable permalink URL from anchor element"),
  imageUrls: I(a()).optional().describe("Image URLs contained within this element")
});
c({
  text: a().describe(
    "Broad text-first representation of the page, including visible text, form values, and validation/error text"
  ),
  nodes: I(Hr).describe(
    "Broad snapshot nodes with refIds where possible; not limited to interactive elements"
  ),
  formErrors: I(
    c({
      field: a().describe("Field label or refId"),
      error: a().describe("Linked visible error text"),
      refId: a().describe("refId of the invalid control")
    })
  ).optional().describe("Visible linked form errors grouped by field"),
  url: a().describe("Current page URL"),
  title: a().describe("Current page title"),
  viewport: c({
    width: f().describe("Viewport width in pixels"),
    height: f().describe("Viewport height in pixels")
  }).describe("Viewport dimensions"),
  observationId: a().optional().describe(
    "Opaque ID of the observation lease granted by this snapshot. Pass to subsequent actions to prove they act on fresh observations."
  )
});
const Zt = c({
  refId: J().optional(),
  tag: a(),
  role: a().optional(),
  name: a().optional(),
  text: a().optional(),
  attributes: _(a()).optional().describe("All HTML attributes (raw)"),
  hidden: b().optional(),
  hiddenReason: _e([
    "display-none",
    "visibility-hidden",
    "aria-hidden",
    "opacity-zero",
    "hidden-attr",
    "inert"
  ]).optional(),
  value: a().optional(),
  checked: b().optional(),
  disabled: b().optional(),
  readOnly: b().optional(),
  selected: b().optional().describe("For <option>: selected state"),
  href: a().optional(),
  src: a().optional(),
  alt: a().optional(),
  accept: a().optional().describe("For input[type=file]: accepted MIME/extensions"),
  filesCount: f().optional().describe("For input[type=file]: selected file count"),
  controlType: a().optional(),
  recommendedAction: a().optional(),
  controls: a().optional(),
  expanded: b().optional(),
  children: I(Pr(() => Zt)).optional().describe("Nested descendants up to `depth`")
});
c({
  nodes: I(Zt),
  url: a(),
  title: a()
});
const Wt = c({
  id: f().optional().describe("Tab ID"),
  tabId: f().optional().describe("Tab ID (added by runner)"),
  index: f().optional().describe("Tab index in the window"),
  windowId: f().optional().describe("Window ID"),
  url: a().optional().describe("Tab URL"),
  title: a().optional().describe("Tab title"),
  status: a().optional().describe("Tab status (loading or complete)"),
  active: b().optional().describe("Whether the tab is active"),
  pinned: b().optional().describe("Whether the tab is pinned"),
  highlighted: b().optional().describe("Whether the tab is highlighted"),
  incognito: b().optional().describe("Whether the tab is incognito"),
  favIconUrl: a().optional().describe("Favicon URL"),
  audible: b().optional().describe("Whether the tab is audible"),
  groupId: f().optional().describe("Group ID"),
  openerTabId: f().optional().describe("Opener tab ID"),
  discarded: b().optional().describe("Whether the tab is discarded"),
  autoDiscardable: b().optional().describe("Whether the tab is auto-discardable"),
  width: f().optional().describe("Tab width"),
  height: f().optional().describe("Tab height"),
  sessionId: a().optional().describe("Session ID")
}).passthrough(), Gr = I(Wt), Vt = c({
  id: f().optional().describe("Window ID"),
  focused: b().optional().describe("Whether the window is focused"),
  top: f().optional().describe("Window top position"),
  left: f().optional().describe("Window left position"),
  width: f().optional().describe("Window width"),
  height: f().optional().describe("Window height"),
  tabs: Gr.optional().describe(
    "Array of tabs in the window"
  ),
  incognito: b().optional().describe("Whether the window is incognito"),
  type: a().optional().describe("Window type"),
  state: a().optional().describe("Window state"),
  alwaysOnTop: b().optional().describe("Whether the window is always on top"),
  sessionId: a().optional().describe("Session ID")
}).passthrough();
I(Vt);
const Jr = c({
  name: a().describe("Cookie name"),
  value: a().describe("Cookie value"),
  domain: a().optional().describe("Cookie domain"),
  hostOnly: b().optional().describe("Whether the cookie is host-only"),
  path: a().optional().describe("Cookie path"),
  secure: b().optional().describe("Whether the cookie is secure"),
  httpOnly: b().optional().describe("Whether the cookie is HTTP-only"),
  sameSite: a().optional().describe("SameSite policy"),
  session: b().optional().describe("Whether the cookie is a session cookie"),
  expirationDate: f().optional().describe("Expiration date as Unix timestamp"),
  storeId: a().optional().describe("Store ID")
}).nullable();
I(
  Jr.nullable().unwrap()
);
const Yr = c({
  id: a().describe("Bookmark ID"),
  parentId: a().optional().describe("Parent folder ID"),
  index: f().optional().describe("Bookmark index"),
  url: a().optional().describe("Bookmark URL"),
  title: a().describe("Bookmark title"),
  dateAdded: f().optional().describe("Date added"),
  dateGroupModified: f().optional().describe("Date group modified"),
  children: I(c({ id: a() }).passthrough()).optional().describe("Child bookmarks")
}).passthrough();
I(Yr);
const Kr = c({
  id: a().describe("History item ID"),
  url: a().optional().describe("URL"),
  title: a().optional().describe("Title"),
  lastVisitTime: f().optional().describe("Last visit time"),
  visitCount: f().optional().describe("Visit count"),
  typedCount: f().optional().describe("Typed count")
}).passthrough();
I(Kr);
const Qr = c({
  frameId: f().describe("Frame ID"),
  result: v().optional().describe("Script result")
});
I(Qr);
a();
b();
T([a(), f()]);
b();
const Xr = c({
  id: f().optional().describe("Group ID"),
  collapsed: b().optional().describe("Whether the group is collapsed"),
  color: a().optional().describe("Group color"),
  title: a().optional().describe("Group title"),
  windowId: f().optional().describe("Window ID")
}).passthrough();
I(Xr);
const en = c({
  lastModified: f().optional().describe("Last modified time"),
  tab: Wt.optional().describe("Tab info"),
  window: Vt.optional().describe("Window info")
}).passthrough(), tn = I(en), rn = c({
  deviceName: a().optional().describe("Device name"),
  sessions: tn.optional().describe("Sessions")
}).passthrough();
I(rn);
const nn = c({
  id: f().optional().describe("Download ID"),
  url: a().optional().describe("Download URL"),
  filename: a().optional().describe("Filename"),
  startTime: a().optional().describe("Start time"),
  endTime: a().optional().describe("End time"),
  state: a().optional().describe("Download state"),
  danger: a().optional().describe("Danger type"),
  paused: b().optional().describe("Whether the download is paused"),
  error: a().optional().describe("Error message"),
  bytesReceived: f().optional().describe("Bytes received"),
  totalBytes: f().optional().describe("Total bytes"),
  fileSize: f().optional().describe("File size"),
  mime: a().optional().describe("MIME type"),
  incognito: b().optional().describe("Whether the download is incognito"),
  referrer: a().optional().describe("Referrer URL"),
  byExtensionId: a().optional().describe("Extension ID"),
  byExtensionName: a().optional().describe("Extension name")
}).passthrough();
I(nn);
f();
c({
  archName: a().describe("CPU architecture"),
  modelName: a().describe("CPU model"),
  numOfProcessors: f().describe("Number of processors"),
  features: I(a()).describe("CPU features")
});
c({
  capacity: f().describe("Total memory capacity"),
  availableCapacity: f().describe("Available memory capacity")
});
I(
  c({
    id: a().describe("Storage ID"),
    name: a().describe("Storage name"),
    type: a().describe("Storage type"),
    capacity: f().describe("Storage capacity")
  })
);
M();
M();
M({
  value: a().optional().describe("Value to fill into the element")
});
M({
  text: a().optional().describe("Text to type into the element")
});
c({
  key: a().optional().describe("Key to press (e.g. Enter, Escape, ArrowDown)")
});
M({
  value: a().optional().describe("Value to select in the dropdown")
});
M({
  checked: b().optional().describe("Desired checked state (true to check, false to uncheck)")
});
M();
c({});
c({
  direction: a().optional().describe("Scroll direction: up, down, left, or right"),
  amount: f().optional().describe("Pixels to scroll")
});
M();
M({
  text: a().optional().describe("Text to append into the element")
});
c({});
c({});
c({
  duration: j().default(1000n).describe("Duration to wait in milliseconds")
});
c({
  interactive_only: b().default(!1).describe("Only include interactive elements"),
  max_nodes: j().default(500n).describe("Maximum number of nodes to include in snapshot")
});
c({
  interactive_only: b().default(!1).describe("Only include interactive elements"),
  max_nodes: j().default(500n).describe("Maximum number of nodes to include in snapshot")
});
c({
  interactive_only: b().default(!1).describe("Only include interactive elements"),
  max_nodes: j().default(500n).describe("Maximum number of nodes to include in snapshot")
});
c({
  interactive_only: b().default(!1).describe("Only include interactive elements"),
  max_nodes: j().default(500n).describe("Maximum number of nodes to include in snapshot")
});
c({
  snapshot: c({}).passthrough().describe("Raw DOM snapshot data to format"),
  format: a().optional().describe("Output format (e.g. markdown, html)")
});
c({
  max_nodes: f().optional().describe("Maximum nodes to include"),
  options: c({}).passthrough().optional().describe("Snapshot options")
}).passthrough();
c({
  max_nodes: f().optional().describe("Maximum nodes to include"),
  options: c({}).passthrough().optional().describe("Snapshot options")
}).passthrough();
c({
  max_nodes: f().optional().describe("Maximum nodes to include"),
  options: c({}).passthrough().optional().describe("Snapshot options")
}).passthrough();
const sn = c({
  role: T([a(), I(a())]).optional().describe("Filter by ARIA role"),
  tag: T([a(), I(a())]).optional().describe("Filter by HTML tag"),
  text: a().optional().describe("Filter by text content (case-insensitive substring)"),
  name: a().optional().describe("Filter by accessible name (case-insensitive substring)"),
  interactiveOnly: b().optional().describe("Only include interactive elements"),
  href: a().optional().describe("Filter by href pattern (case-insensitive substring)"),
  src: a().optional().describe("Filter by src pattern (case-insensitive substring)"),
  limit: f().positive().optional().describe("Maximum filtered nodes to return")
}).passthrough(), an = c({
  filter: sn.optional().describe(
    "Semantic filter criteria"
  ),
  max_nodes: f().optional().describe("Maximum nodes to collect before filtering")
}).passthrough();
an.extend({
  tabId: f().describe("Tab ID")
});
c({
  key: a().describe("Storage key to retrieve")
});
c({
  key: a().describe("Storage key to set"),
  value: a().describe("Value to store")
});
c({
  key: a().describe("Storage key to delete")
});
c({});
const on = c({
  items: _(a()).describe("Record of key-value string pairs to store")
});
ee((t) => t !== null && typeof t == "object" && !Array.isArray(t) && !("items" in t) ? { items: t } : t, on);
const dn = c({
  keys: I(a()).describe("Array of storage keys to retrieve"),
  defaults: _(a()).optional().describe("Default string values for missing keys")
});
ee(
  (t) => Array.isArray(t) ? { keys: t } : t,
  dn
);
c({});
const cn = c({
  keys: I(a()).describe("Array of storage keys to delete")
});
ee(
  (t) => Array.isArray(t) ? { keys: t } : t,
  cn
);
c({});
c({
  active: b().optional().describe("Whether the tabs are active"),
  currentWindow: b().optional().describe("Whether the tabs are in the current window"),
  url: a().optional().describe("URL pattern to match tabs against")
}).passthrough();
ee(
  (t) => typeof t == "string" ? { url: t } : t,
  c({
    url: a().optional().describe("URL to open in the new tab"),
    active: b().optional().describe("Whether to focus the new tab"),
    waitForReady: b().optional().describe("Wait for page load and content-script readiness")
  })
);
T([
  f(),
  I(
    c({
      id: f().optional(),
      tabId: f().optional(),
      tab_id: f().optional()
    }).passthrough()
  ),
  c({
    id: f().optional(),
    tabId: f().optional(),
    tab_id: f().optional()
  }).passthrough()
]);
B();
B({
  value: a().describe("Value to fill into the element")
});
const ln = B({
  files: I(jt).min(1).describe("Files to attach to the input")
});
B({
  files: I(Dt).min(1).describe("Resolved files for content-script application")
});
ee(
  (t) => typeof t == "string" || typeof t == "number" ? { __invalidPositional: t } : t,
  c({
    __invalidPositional: T([a(), f()]).optional().describe("Internal flag for positional argument rejection"),
    ...le,
    refId: J().optional().describe("Element reference ID (e.g. e2)"),
    label: a().optional().describe("Human-readable element label"),
    x: f().optional().describe("X coordinate to scroll to"),
    y: f().optional().describe("Y coordinate to scroll to")
  }).superRefine(Pt)
);
B({
  text: a().describe("Text to type into the element")
});
c({
  ...le,
  key: a().describe("Key to press (e.g. Enter, Escape, ArrowDown)")
});
B({
  value: a().describe("Value to select in the dropdown")
});
B({
  value: a().describe(
    "Visible text of the option to select (matched case-insensitively)"
  )
});
B({
  checked: b().optional().describe("Desired checked state (true to check, false to uncheck)")
});
B();
B();
c({
  ...le,
  name: a().min(1).describe("The `name` attribute of the radio group to pick from"),
  value: a().describe("The `value` of the radio option to check")
});
c({
  ...le
});
c({
  ...le,
  direction: a().default("down").describe("Scroll direction: up, down, left, or right"),
  amount: f().default(300).describe("Pixels to scroll")
});
B();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID"),
  script: a().optional().describe("Script to evaluate"),
  code: a().optional().describe("Alternative script code"),
  js: a().optional().describe("Alternative JS code")
}).passthrough();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID")
}).passthrough();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID")
}).passthrough();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID"),
  timeout: f().optional().describe("Timeout in milliseconds")
}).passthrough();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID"),
  url: a().optional().describe("URL to fetch"),
  options: c({}).passthrough().optional().describe("Fetch options")
}).passthrough();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID"),
  max_nodes: f().optional().describe("Maximum nodes to include"),
  options: c({}).passthrough().optional().describe("Snapshot options")
}).passthrough();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID"),
  max_nodes: f().optional().describe("Maximum nodes to include"),
  options: c({}).passthrough().optional().describe("Snapshot options")
}).passthrough();
c({
  tabId: T([f(), Y()]).optional().describe("Target tab ID"),
  max_nodes: f().optional().describe("Maximum nodes to include"),
  options: c({}).passthrough().optional().describe("Snapshot options")
}).passthrough();
c({
  ...le,
  url: a().describe("URL to navigate the tab to"),
  timeout: j().optional().describe("Navigation timeout in milliseconds"),
  waitUntil: _e(["load", "networkidle"]).optional().describe(
    "When to consider navigation complete: 'load' (tab status complete) or 'networkidle' (no in-flight requests for 500ms)"
  )
}).passthrough();
const We = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  none: 5
}, un = [
  "trace",
  "debug",
  "info",
  "warn",
  "error",
  "none"
];
function fn(t) {
  const e = Math.max(0, Math.min(5, Math.round(t)));
  return un[e] ?? "error";
}
let ut = "trace", it = null;
function pn(t) {
  ut = t, it && it(We[t]);
}
function hn(t) {
  it = t, t(We[ut]);
}
function mn(t) {
  return We[t] >= We[ut];
}
function Ft(t, e = "info") {
  var r;
  if (t === null) return "null";
  if (t === void 0) return "undefined";
  if (typeof t == "string") return t;
  if (typeof t == "number" || typeof t == "boolean")
    return String(t);
  if (typeof t == "bigint") return `${t}n`;
  if (t instanceof Error) {
    const n = e === "debug" || e === "trace" ? t.stack : (r = t.stack) == null ? void 0 : r.split(`
`)[0];
    return JSON.stringify({ message: t.message, name: t.name, stack: n });
  }
  if (typeof t == "function") return "[Function]";
  if (typeof t == "symbol") return String(t);
  if (typeof t == "object")
    try {
      return JSON.stringify(t);
    } catch (n) {
      return n instanceof TypeError && n.message.includes("circular") ? "[Circular]" : `[Unserializable: ${n instanceof Error ? n.message : String(n)}]`;
    }
  return String(t);
}
function gn(t) {
  return `[extension-js][${t}]`;
}
function yn(t, e) {
  if (!t) return "";
  const r = [];
  try {
    for (const [n, s] of Object.entries(t))
      r.push(`${n}=${Ft(s, e)}`);
  } catch {
    return " metadata=[unreadable]";
  }
  return r.length > 0 ? ` ${r.join(" ")}` : "";
}
function ve(t, e) {
  return e.length === 0 ? { event: t } : e.length === 1 && typeof e[0] == "object" && e[0] !== null && !Array.isArray(e[0]) ? { event: t, metadata: e[0] } : {
    event: t,
    metadata: { _args: e.map((r) => Ft(r)).join(" ") }
  };
}
class ft {
  constructor(e = "root") {
    this.namespace = e;
  }
  log(e, r, n) {
    try {
      if (!mn(e)) return;
      const s = gn(this.namespace), i = yn(n, e), d = `${s} ${r}${i}`;
      switch (e) {
        case "trace":
        case "debug":
        case "info":
          console.log(d);
          break;
        case "warn":
          console.warn(d);
          break;
        case "error":
          console.error(d);
          break;
        case "none":
          break;
        default: {
          const o = e;
          break;
        }
      }
    } catch {
    }
  }
  trace(e, ...r) {
    const { event: n, metadata: s } = ve(e, r);
    this.log("trace", n, s);
  }
  debug(e, ...r) {
    const { event: n, metadata: s } = ve(e, r);
    this.log("debug", n, s);
  }
  info(e, ...r) {
    const { event: n, metadata: s } = ve(e, r);
    this.log("info", n, s);
  }
  warn(e, ...r) {
    const { event: n, metadata: s } = ve(e, r);
    this.log("warn", n, s);
  }
  error(e, ...r) {
    const { event: n, metadata: s } = ve(e, r);
    this.log("error", n, s);
  }
  child(e) {
    return new ft(`${this.namespace}.${e}`);
  }
  timer(e, r, n = "info") {
    const s = typeof performance < "u" && performance.now, i = s ? performance.now() : Date.now();
    return (d) => {
      try {
        const o = s ? performance.now() : Date.now(), p = Math.round(o - i), l = {
          ...r,
          ...d,
          duration_ms: p
        };
        this.log(n, e, l);
      } catch {
      }
    };
  }
}
const O = new ft("root"), bn = /* @__PURE__ */ new Set();
function _n(t) {
  return bn.has(t);
}
const Ut = /* @__PURE__ */ new Map();
function vn(t, e) {
  Ut.set(t, e);
}
function kn(t) {
  return Ut.get(t);
}
function wn(t) {
  return t.startsWith("tab_") ? "required" : "active";
}
function xn(t) {
  return t === "content-script" ? "content-script" : t === "main-thread" ? "main-thread" : t === "worker" ? "worker:default" : t.startsWith("worker:") ? t : "main-thread";
}
function Tn(t, e) {
  return e !== "main-thread" ? e : _n(t) ? "content-script" : e;
}
function Sn(t, e) {
  return {
    endpoint: xn(Tn(t, e)),
    tabPolicy: wn(t)
  };
}
function In(t) {
  for (const e of t)
    vn(e.action, Sn(e.action, e.owner));
}
O.child("tool-registry");
const Ve = /* @__PURE__ */ new Map(), Fe = /* @__PURE__ */ new Map();
function pt(t) {
  return t && t.length > 0 ? t : "__default__";
}
function Bt(t) {
  const e = pt(t);
  let r = Ve.get(e);
  return r || (r = /* @__PURE__ */ new Map(), Ve.set(e, r)), r;
}
function En(t, e, r) {
  const n = pt(t), s = (Fe.get(n) ?? 0) + 1;
  Fe.set(n, s);
  const i = `blob_${s}`;
  return Bt(t).set(i, {
    bytes: e,
    mimeType: r == null ? void 0 : r.mimeType,
    contentType: r == null ? void 0 : r.contentType
  }), i;
}
function Rn(t, e) {
  const r = Bt(t), n = r.get(e) ?? null;
  return n && r.delete(e), n;
}
function Cn(t) {
  const e = pt(t);
  Ve.delete(e), Fe.delete(e);
}
function St() {
  Ve.clear(), Fe.clear();
}
const It = 8 * 1024;
function An(t) {
  const e = atob(t), r = new Uint8Array(e.length);
  for (let n = 0; n < e.length; n++)
    r[n] = e.charCodeAt(n);
  return r;
}
function On(t) {
  let e = "";
  for (let r = 0; r < t.length; r += It) {
    const n = t.subarray(r, r + It);
    for (let s = 0; s < n.length; s++)
      e += String.fromCharCode(n[s]);
  }
  return btoa(e);
}
function Mn(t) {
  if (typeof t != "object" || t === null) return !1;
  const e = t;
  if (e.store === !0) return !0;
  const r = e.options;
  return typeof r == "object" && r !== null ? r.store === !0 : !1;
}
function zt(t, e, r) {
  if (!Mn(t) || typeof e != "object" || e === null || !("bodyEncoding" in e))
    return e;
  const n = e;
  if (n.bodyEncoding !== "base64" || !n.body)
    return e;
  const s = An(n.body), i = En(r, s, {
    contentType: n.contentType,
    mimeType: n.contentType
  }), { body: d, ...o } = n;
  return {
    ...o,
    bodyEncoding: "handle",
    handle: i
  };
}
function Et(t, e) {
  const n = (t.split(/[?#]/)[0] ?? t).split("/").filter(Boolean).pop();
  return n && n.length > 0 ? n : e;
}
function Je(t) {
  return {
    ok: !1,
    error: {
      message: t,
      code: "E_INVALID_PARAMS",
      category: "validation"
    }
  };
}
async function Nn(t, e, r, n) {
  var p;
  const i = (t === "tab_set_files" ? ln : Br).safeParse(e);
  if (!i.success)
    return Je(
      ((p = i.error.issues[0]) == null ? void 0 : p.message) ?? "Invalid setFiles params"
    );
  const d = i.data, o = [];
  for (const l of d.files) {
    if (l.url) {
      o.push({
        kind: "url",
        url: l.url,
        name: l.name ?? Et(l.url, "upload.bin"),
        mimeType: l.mimeType
      });
      continue;
    }
    if (l.path) {
      try {
        const m = await n(l.path);
        o.push({
          kind: "bytes",
          name: l.name ?? Et(l.path, "upload.bin"),
          data: m,
          mimeType: l.mimeType
        });
      } catch (m) {
        const R = m instanceof Error ? m.message : String(m);
        return Je(`Failed to read path ${l.path}: ${R}`);
      }
      continue;
    }
    if (l.handle) {
      const m = Rn(r, l.handle);
      if (!m)
        return Je(`Unknown or expired handle: ${l.handle}`);
      o.push({
        kind: "bytes",
        name: l.name ?? l.handle,
        data: On(m.bytes),
        mimeType: l.mimeType ?? m.mimeType ?? m.contentType
      });
    }
  }
  return {
    ok: !0,
    value: {
      ...d,
      files: o
    }
  };
}
const Ue = /* @__PURE__ */ new Map();
function $n(t, e) {
  Ue.set(t, e);
}
function Ln(t) {
  const e = Ue.get(t);
  return e !== void 0 && Ue.delete(t), e;
}
function Pn() {
  Ue.clear();
}
const qt = /* @__PURE__ */ new Set(["page_set_files", "tab_set_files"]), Ht = /* @__PURE__ */ new Set(["page_fetch", "tab_fetch"]);
let W = null, at = !1;
const he = /* @__PURE__ */ new Map();
function Be(t, e) {
  try {
    return t.postMessage(e), !0;
  } catch (r) {
    const n = r instanceof Error ? r.message : String(r);
    return O.error("port_post_failed", { error: n }), !1;
  }
}
const Rt = 1e3;
function Gt(t, e, r) {
  e === "main-thread" || e === "content-script" ? Be(r, { type: "relayCancel", id: t, owner: e }) : Be(r, { type: "registryCallCancel", id: t });
}
function Ct(t, e) {
  for (const [r, n] of he)
    clearTimeout(n.timeoutId), Gt(r, n.owner, n.port), n.settle({
      ok: !1,
      error: { message: e, code: t }
    }), he.delete(r);
}
const ce = /* @__PURE__ */ new Map(), Jt = /* @__PURE__ */ new Map(), Yt = /* @__PURE__ */ new Map(), Kt = /* @__PURE__ */ new Map(), Qt = /* @__PURE__ */ new Map(), z = /* @__PURE__ */ new Map();
let At = Promise.resolve(), V = null;
function jn(t) {
  O.trace("sessionQueue_enqueue");
  const e = At.then(t);
  return At = e.then(
    () => {
    },
    () => {
    }
  ), e;
}
function Xt(t) {
  V && (O.error("runCell_worker_failure", {
    runId: V.runId,
    callId: V.id,
    error: t
  }), self.postMessage({
    type: "error",
    id: V.id,
    error: t,
    runId: V.runId
  }), V = null);
}
self.addEventListener("error", (t) => {
  const e = t.message || (t.error instanceof Error ? t.error.message : "Worker uncaught error");
  O.error("worker_uncaught_error", { error: e }), Xt(e);
});
self.addEventListener("unhandledrejection", (t) => {
  const e = t.reason, r = e instanceof Error ? e.message : String(e ?? "Unhandled rejection");
  O.error("worker_unhandled_rejection", { error: r }), Xt(r);
});
function Dn(t, e, r = ce) {
  r.set(t, e);
}
function C(t, e, r, n = ce) {
  Dn(
    t,
    async (s, i) => {
      const d = e.safeParse(me(s));
      if (!d.success) {
        const o = Dr(
          t,
          e,
          d.error.issues,
          s
        ), p = new Error(o);
        throw p.code = "E_INVALID_PARAMS", p;
      }
      return await r(d.data, i);
    },
    n
  );
}
function Zn() {
  const t = new Uint8Array(16);
  return crypto.getRandomValues(t), Array.from(t, (e) => e.toString(16).padStart(2, "0")).join("");
}
function Wn(t) {
  return fn(t);
}
const ot = /* @__PURE__ */ new Map(), Pe = /* @__PURE__ */ new Map();
function Vn(t, e) {
  var r;
  if (ot.has(t))
    throw new Error(`Worker port already registered for owner: ${t}`);
  if (typeof e.addEventListener != "function")
    throw new Error(
      `Worker port for owner "${t}" cannot receive responses`
    );
  ot.set(t, e), e.addEventListener("message", async (n) => {
    var i;
    const s = n.data;
    if (s !== null && (s.type === "asyncRelayResult" || s.type === "registryCallResult") && typeof s.id == "string") {
      dt(s.id, s.result);
      return;
    }
    if (s !== null && s.type === "registryCallCancel" && typeof s.id == "string") {
      (i = Pe.get(s.id)) == null || i.abort(), Pe.delete(s.id);
      return;
    }
    if (s !== null && s.type === "registryCall" && typeof s.id == "string" && typeof s.action == "string") {
      const d = s.id, o = new AbortController();
      Pe.set(d, o);
      const p = ce.get(s.action);
      let l;
      if (!p)
        l = {
          ok: !1,
          error: {
            message: `Unknown worker action: ${s.action}`,
            code: "E_UNKNOWN"
          }
        };
      else
        try {
          const m = await p(s.params, {
            action: s.action,
            callId: s.callId,
            runId: s.runId,
            signal: o.signal
          });
          l = o.signal.aborted ? {
            ok: !1,
            error: { message: "Relay aborted", code: "E_ABORT" }
          } : { ok: !0, value: m };
        } catch (m) {
          l = {
            ok: !1,
            error: {
              message: m instanceof Error ? m.message : String(m),
              code: o.signal.aborted ? "E_ABORT" : "E_WORKER_HANDLER"
            }
          };
        }
      Pe.delete(d), Be(e, { type: "registryCallResult", id: d, result: l }) || dt(d, {
        ok: !1,
        error: {
          message: "Failed to deliver worker handler response",
          code: "E_PORT"
        }
      });
    }
  }), (r = e.start) == null || r.call(e);
}
function dt(t, e) {
  O.trace("resolveAsyncRelayResult", { id: t });
  const r = he.get(t);
  return r ? (r.settle(e), !0) : (O.warn("asyncRelayResult_no_pending_relay", { id: t }), !1);
}
function Fn(t) {
  if (t === "main-thread" || t === "content-script")
    return self;
  const e = ot.get(t);
  return e || null;
}
function er(t) {
  const { owner: e, action: r, tabPolicy: n, resolveTimeoutMs: s } = t, i = t.timeoutMs ?? we;
  return (d, o) => {
    O.trace("safePostAsCall_invoke", {
      owner: e,
      action: r,
      callId: o == null ? void 0 : o.callId,
      runId: o == null ? void 0 : o.runId
    });
    const p = (s == null ? void 0 : s(d)) ?? i;
    return new Promise((l, m) => {
      var bt;
      if ((bt = o == null ? void 0 : o.signal) != null && bt.aborted) {
        const K = new Error(`Relay aborted for action: ${r}`);
        K.code = "E_ABORT", m(K);
        return;
      }
      const R = Fn(e);
      if (!R) {
        m(new Error(`No port available for action: ${r}`));
        return;
      }
      if (he.size >= Rt) {
        m(
          new Error(
            `Too many pending calls (${Rt} limit exceeded). Action: ${r}`
          )
        );
        return;
      }
      const $ = Zn();
      let te = !1;
      const ue = (K) => {
        te || (te = !0, clearTimeout(mt), o != null && o.signal && o.signal.removeEventListener("abort", He), he.delete($), K());
      }, ht = () => {
        Gt($, e, R);
      }, He = () => {
        ht();
        const K = new Error(`Relay aborted for action: ${r}`);
        K.code = "E_ABORT", ue(() => m(K));
      };
      o != null && o.signal && o.signal.addEventListener("abort", He);
      const mt = setTimeout(() => {
        ht(), ue(() => m(new Error(`Relay timeout for action: ${r}`)));
      }, p);
      he.set($, {
        settle: (K) => ue(() => l(K)),
        timeoutId: mt,
        abort: He,
        owner: e,
        port: R
      });
      const gt = o == null ? void 0 : o.runId, yt = o == null ? void 0 : o.callId;
      Be(R, {
        type: e === "main-thread" || e === "content-script" ? "asyncRelay" : "registryCall",
        id: $,
        owner: e,
        action: r,
        params: d,
        callId: yt,
        tabPolicy: n,
        command: { action: r, params: d, runId: gt, callId: yt },
        runId: gt
      }) || ue(
        () => m(new Error(`Failed to post relay for action: ${r}`))
      );
    });
  };
}
const Un = "worker", we = 3e4, Ot = 5e3, Bn = 500, zn = {
  page_goto: "timeout",
  page_wait_for: "timeout",
  tab_wait_for_load: "timeout",
  fetch: "timeout",
  sleep: "duration",
  page_wait: "duration",
  sidepanel_wait: "duration"
}, tr = /* @__PURE__ */ new Set(["page_goto"]);
function qn(t, e) {
  if (t === null || typeof t != "object" || Array.isArray(t))
    return null;
  const r = t[e];
  return typeof r == "bigint" ? Number(r) : typeof r == "number" && Number.isFinite(r) ? r : null;
}
function Hn(t, e) {
  return tr.has(t) ? e * 3 + Bn + Ot : e + Ot;
}
const Gn = 6e4;
function rr(t, e) {
  if (qt.has(t))
    return Gn;
  const r = zn[t];
  if (!r) return we;
  let n = qn(e, r);
  return n === null && tr.has(t) && (n = we), n === null ? we : Math.max(
    we,
    Hn(t, n)
  );
}
async function nr(t, e, r) {
  if (!qt.has(t))
    return { ok: !0, params: e };
  if (!W)
    return {
      ok: !1,
      error: { message: "Session not initialized", code: "E_INTERNAL" }
    };
  const n = await Nn(
    t,
    e,
    r,
    async (s) => {
      const i = or(s);
      if (i !== void 0)
        return i;
      const d = Ln(s);
      return d !== void 0 ? d : await dr(s);
    }
  );
  return n.ok ? { ok: !0, params: n.value } : n;
}
function ns(t, e) {
  t = me(t);
  const r = e == null ? void 0 : e.action;
  if (O.trace("extensionDispatch", {
    action: r,
    callId: e == null ? void 0 : e.callId,
    runId: e == null ? void 0 : e.runId
  }), !r)
    return Promise.resolve({
      ok: !1,
      error: {
        message: "Missing action in dispatch context",
        code: "E_MISSING_ACTION"
      }
    });
  const n = t;
  return (async () => {
    var p, l;
    const s = await nr(
      r,
      t,
      e == null ? void 0 : e.runId
    );
    if (!s.ok)
      return s;
    if (t = s.params, ce.has(r)) {
      const m = ce.get(r), R = (e == null ? void 0 : e.signal) ?? (e != null && e.runId ? (p = z.get(e.runId)) == null ? void 0 : p.signal : void 0);
      return (async () => {
        try {
          return { ok: !0, value: await m(t, { ...e, signal: R }) };
        } catch ($) {
          const te = $ instanceof Error ? $.message : String($), ue = typeof $ == "object" && $ !== null && "code" in $ && typeof $.code == "string" ? $.code : "E_WORKER_HANDLER";
          return { ok: !1, error: { message: te, code: ue } };
        }
      })();
    }
    const i = kn(r);
    if (!i)
      return Promise.resolve({
        ok: !1,
        error: {
          message: `No route registered for action: ${r}`,
          code: "E_NO_ROUTE"
        }
      });
    const o = await er({
      owner: i.endpoint,
      action: r,
      resolveTimeoutMs: (m) => rr(r, m),
      tabPolicy: i.tabPolicy
    })(t, {
      ...e,
      signal: (e == null ? void 0 : e.signal) ?? (e != null && e.runId ? (l = z.get(e.runId)) == null ? void 0 : l.signal : void 0)
    });
    return Ht.has(r) && typeof o == "object" && o !== null && "ok" in o && o.ok ? {
      ok: !0,
      value: zt(
        n,
        o.value,
        e == null ? void 0 : e.runId
      )
    } : o;
  })();
}
function Jn(t) {
  if (t.owner === Un) {
    const e = ce.get(t.action);
    if (!e)
      throw new Error(
        `No worker-local handler registered for action: ${t.action}`
      );
    return async (r, n) => {
      var i;
      r = me(r);
      const s = (n == null ? void 0 : n.signal) ?? (n != null && n.runId ? (i = z.get(n.runId)) == null ? void 0 : i.signal : void 0);
      try {
        return { ok: !0, value: await e(r, {
          ...n,
          action: t.action,
          signal: s
        }) };
      } catch (d) {
        const o = d instanceof Error ? d.message : String(d), p = typeof d == "object" && d !== null && "code" in d && typeof d.code == "string" ? d.code : t.errorCode;
        return { ok: !1, error: { message: o, code: p } };
      }
    };
  } else {
    const e = er({
      owner: t.owner,
      action: t.action,
      resolveTimeoutMs: (r) => rr(t.action, r)
    });
    return async (r, n) => {
      var d;
      const s = me(r), i = await nr(
        t.action,
        s,
        n == null ? void 0 : n.runId
      );
      if (!i.ok)
        return i;
      try {
        const o = await e(i.params, {
          ...n,
          signal: (n == null ? void 0 : n.signal) ?? (n != null && n.runId ? (d = z.get(n.runId)) == null ? void 0 : d.signal : void 0)
        });
        return typeof o == "object" && o !== null && "ok" in o && o.ok && Ht.has(t.action) ? {
          ok: !0,
          value: zt(
            s,
            o.value,
            n == null ? void 0 : n.runId
          )
        } : o;
      } catch (o) {
        const p = o instanceof Error ? o.message : String(o), l = typeof o == "object" && o !== null && "code" in o && typeof o.code == "string" ? o.code : t.errorCode || "E_RELAY";
        return { ok: !1, error: { message: p, code: l } };
      }
    };
  }
}
function Yn(t) {
  C(
    "exists",
    D,
    (e) => t.fsExists(e)
  ), C(
    "stat",
    D,
    (e) => t.fsStat(e)
  ), C(
    "read",
    D,
    (e) => t.fsRead(e)
  ), C(
    "readText",
    D,
    (e) => t.fsReadText(e)
  ), C(
    "readBase64",
    D,
    (e) => t.fsReadBase64(e)
  ), C(
    "list",
    D,
    (e) => t.fsList(e)
  ), C(
    "mkdir",
    D,
    (e) => t.fsMkdir(e)
  ), C(
    "delete",
    D,
    (e) => t.fsDelete(e)
  ), C(
    "copy",
    Tt,
    (e) => t.fsCopy(e)
  ), C(
    "move",
    Tt,
    (e) => t.fsMove(e)
  ), C(
    "write",
    fe,
    (e) => t.fsWrite(e)
  ), C(
    "writeText",
    fe,
    (e) => t.fsWriteText(e)
  ), C(
    "writeBase64",
    fe,
    async (e) => {
      const r = e;
      return $n(r.path, r.data), t.fsWriteBase64(r);
    }
  ), C(
    "append",
    fe,
    (e) => t.fsAppend(e)
  ), C(
    "appendText",
    fe,
    (e) => t.fsAppendText(e)
  ), C(
    "appendBase64",
    fe,
    (e) => t.fsAppendBase64(e)
  ), C(
    "readRange",
    Wr,
    (e) => t.fsReadRange(e)
  ), C(
    "update",
    Vr,
    (e) => t.fsUpdate(e)
  ), C(
    "hash",
    Fr,
    (e) => t.fsHash(e)
  );
}
function Kn(t) {
  C(
    "parse",
    D,
    (e) => t.csvParse(e),
    Jt
  );
}
function Qn(t) {
  C(
    "list",
    D,
    (e) => t.zipList(e),
    Yt
  );
}
function Xn(t) {
  C(
    "read",
    D,
    (e) => t.xlsxRead(e),
    Kt
  );
}
function es(t) {
  C(
    "text",
    D,
    (e) => t.pdfText(e),
    Qt
  );
}
async function ts(t, e) {
  if (at) return;
  await sr(), W = new ir(), Ye(0), hn(Ye), O.trace("initWasm_start"), Yn(W), Kn(W), es(W), Qn(W), Xn(W), In(t);
  const n = t.map((i) => ({
    entry: lr(i),
    callback: Jn(i)
  }));
  try {
    ar(n);
  } catch (i) {
    const d = i instanceof Error ? i.message : String(i);
    throw new Error(`Registry registration failed: ${d}`);
  }
  const { freezeManifest: s } = await import("./extension_js.js");
  try {
    s();
  } catch (i) {
    const d = i instanceof Error ? i.message : String(i);
    throw new Error(`Manifest freeze failed: ${d}`);
  }
  if (W.injectRegistryBindings(), e) {
    const i = JSON.stringify(e);
    await W.runCellAsync(
      `(function(){var r=globalThis.chrome&&globalThis.chrome.runtime;if(!r){r={};if(!globalThis.chrome)globalThis.chrome={};globalThis.chrome.runtime=r;}r.id=${i};})();`,
      "",
      "inject-runtime-id"
    );
  }
  at = !0, O.trace("initWasm_done");
}
self.onmessage = async (t) => {
  const e = t.data;
  if (O.trace("onmessage", {
    type: e.type,
    id: "id" in e ? e.id : void 0
  }), e.type === "asyncRelayResult") {
    O.trace("asyncRelayResult", { id: e.id }), dt(e.id, e.result);
    return;
  }
  if (e.type === "registerWorkerPort") {
    const n = t.ports[0];
    if (!n) {
      O.error("register_worker_port_missing", { owner: e.owner });
      return;
    }
    Vn(e.owner, n);
    return;
  }
  if (e.type === "init") {
    try {
      await ts(e.manifest, e.extensionId), self.postMessage({ type: "ready" });
    } catch (n) {
      const s = n instanceof Error ? n.message : String(n);
      O.error("worker_init_failed", { error: s }), self.postMessage({
        type: "error",
        error: `WASM init failed: ${s}`
      });
    }
    return;
  }
  if (e.type === "setLogLevel") {
    Ye(e.level), pn(Wn(e.level)), O.trace("set_log_level", { level: e.level });
    return;
  }
  if (!at || !W) {
    self.postMessage({
      type: "error",
      id: e.id,
      error: "WASM not initialized"
    });
    return;
  }
  const r = W;
  await jn(async () => {
    switch (e.type) {
      case "runCell": {
        const n = e.runId, s = new AbortController();
        n && z.set(n, s), V = { id: e.id, runId: n }, O.trace("runCell_start", {
          runId: n,
          callId: e.id,
          codeLen: e.code.length
        });
        try {
          const i = await r.runCellAsync(
            e.code,
            e.stdin || "",
            n || ""
          );
          O.trace("runCell_done", {
            runId: n,
            callId: e.id,
            status: i.status
          }), self.postMessage({
            type: "result",
            id: e.id,
            data: i,
            runId: n
          });
        } catch (i) {
          const d = i instanceof Error ? i.message : String(i), o = i instanceof Error ? i.name : void 0, p = i instanceof Error ? i.stack : void 0;
          let l;
          if (p) {
            const R = p.match(/:(\d+):\d+\)?$/m);
            R && (l = parseInt(R[1], 10));
          }
          O.error("runCell_error", { runId: n, error: d, name: o, line: l });
          const m = i instanceof Error ? {
            name: o,
            message: d,
            stack: p,
            ...l !== void 0 ? { line: l } : {}
          } : { message: d };
          self.postMessage({
            type: "error",
            id: e.id,
            error: m,
            runId: n
          });
        } finally {
          (V == null ? void 0 : V.id) === e.id && (V = null), n && (z.delete(n), Cn(n));
        }
        break;
      }
      case "reset": {
        r.setAborted(!0);
        for (const n of z.values())
          n.abort();
        z.clear(), St(), Pn(), cr(), Ct("E_RESET", "Worker reset");
        try {
          r.reset(), self.postMessage({ type: "result", id: e.id, data: { ok: !0 } });
        } catch (n) {
          const s = n instanceof Error ? n.message : String(n);
          self.postMessage({ type: "error", id: e.id, error: s });
        }
        break;
      }
      case "stop": {
        r.setAborted(!0);
        for (const n of z.values())
          n.abort();
        z.clear(), St(), Ct("E_STOPPED", "Worker stopped"), self.postMessage({ type: "result", id: e.id, data: { ok: !0 } });
        break;
      }
      case "setFuelLimit": {
        try {
          r.set_fuel_limit(e.limit), e.id && self.postMessage({
            type: "result",
            id: e.id,
            data: { ok: !0 }
          });
        } catch (n) {
          if (e.id) {
            const s = n instanceof Error ? n.message : String(n);
            self.postMessage({ type: "error", id: e.id, error: s });
          }
        }
        break;
      }
      case "inspectGlobals": {
        try {
          const n = r.inspect_globals();
          self.postMessage({ type: "result", id: e.id, data: n });
        } catch (n) {
          const s = n instanceof Error ? n.message : String(n);
          self.postMessage({ type: "error", id: e.id, error: s });
        }
        break;
      }
      case "apiDocs": {
        try {
          const n = r.apiDocs(e.format);
          self.postMessage({ type: "result", id: e.id, data: n });
        } catch (n) {
          const s = n instanceof Error ? n.message : String(n);
          self.postMessage({ type: "error", id: e.id, error: s });
        }
        break;
      }
      case "loadLibrary": {
        try {
          const n = r.load_library(e.source);
          self.postMessage({ type: "result", id: e.id, data: n });
        } catch (n) {
          const s = n instanceof Error ? n.message : String(n);
          self.postMessage({ type: "error", id: e.id, error: s });
        }
        break;
      }
      case "fsCall": {
        const n = ce.get(e.action);
        if (!n) {
          self.postMessage({
            type: "error",
            id: e.id,
            error: `Unknown fs action: ${e.action}`
          });
          break;
        }
        try {
          const s = await n(e.params);
          self.postMessage({ type: "result", id: e.id, data: s });
        } catch (s) {
          const i = s instanceof Error ? s.message : String(s);
          self.postMessage({ type: "error", id: e.id, error: i });
        }
        break;
      }
      case "csvCall": {
        const n = Jt.get(e.action);
        if (!n) {
          self.postMessage({
            type: "error",
            id: e.id,
            error: `Unknown csv action: ${e.action}`
          });
          break;
        }
        try {
          const s = await n(e.params);
          self.postMessage({ type: "result", id: e.id, data: s });
        } catch (s) {
          const i = s instanceof Error ? s.message : String(s);
          self.postMessage({ type: "error", id: e.id, error: i });
        }
        break;
      }
      case "zipCall": {
        const n = Yt.get(e.action);
        if (!n) {
          self.postMessage({
            type: "error",
            id: e.id,
            error: `Unknown zip action: ${e.action}`
          });
          break;
        }
        try {
          const s = await n(e.params);
          self.postMessage({ type: "result", id: e.id, data: s });
        } catch (s) {
          const i = s instanceof Error ? s.message : String(s);
          self.postMessage({ type: "error", id: e.id, error: i });
        }
        break;
      }
      case "xlsxCall": {
        const n = Kt.get(e.action);
        if (!n) {
          self.postMessage({
            type: "error",
            id: e.id,
            error: `Unknown xlsx action: ${e.action}`
          });
          break;
        }
        try {
          const s = await n(e.params);
          self.postMessage({ type: "result", id: e.id, data: s });
        } catch (s) {
          const i = s instanceof Error ? s.message : String(s);
          self.postMessage({ type: "error", id: e.id, error: i });
        }
        break;
      }
      case "pdfCall": {
        const n = Qt.get(e.action);
        if (!n) {
          self.postMessage({
            type: "error",
            id: e.id,
            error: `Unknown pdf action: ${e.action}`
          });
          break;
        }
        try {
          const s = await n(e.params);
          self.postMessage({ type: "result", id: e.id, data: s });
        } catch (s) {
          const i = s instanceof Error ? s.message : String(s);
          self.postMessage({ type: "error", id: e.id, error: i });
        }
        break;
      }
      default: {
        O.error("unhandled_worker_message", {
          type: e.type
        });
        break;
      }
    }
  });
};
export {
  we as DEFAULT_RELAY_TIMEOUT_MS,
  Jn as createExecutableCallback,
  ns as extensionDispatch,
  Dn as registerWorkerHandler,
  C as registerWorkerHandlerValidated,
  Vn as registerWorkerPort,
  dt as resolveAsyncRelayResult,
  rr as resolveRelayTimeoutMs,
  er as safePostAsCall,
  Ct as settleAllPendingRelays
};
